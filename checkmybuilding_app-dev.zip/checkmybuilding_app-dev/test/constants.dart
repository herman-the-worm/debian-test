import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:checkmybuilding/bootstrap.dart';
import 'package:checkmybuilding/firebase_options_development.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

const String usernameCorrect = 'test_username';
const String passwordCorrect = 'test_password';
const String usernameEmpty = '';
const String passwordEmpty = '';
const String usernameIncorrect = 'test_';
const String passwordIncorrect = 'test_';

Future<void> setUpGlobal({bool? kIsWeb}) async {
  FlutterError.onError = (details) {
    log(details.exceptionAsString(), stackTrace: details.stack);
  };

  Bloc.observer = const AppBlocObserver();
  if (kIsWeb != null) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } else {
    await Firebase.initializeApp(); // normally would initialize Firebase
  }

  FlutterSecureStorage.setMockInitialValues({});
}
