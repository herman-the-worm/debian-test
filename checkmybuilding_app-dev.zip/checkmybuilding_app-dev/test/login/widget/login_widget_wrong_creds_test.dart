import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../constants.dart';
import '../../mock.dart';
import '../../test_dependency_injector.dart';

void main() {
  const screen = 'LogIn';
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen Page wrong username/password input', () {
    testWidgets('Login password field is empty', (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();

// Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
        passwordCorrect,
      );
// Pump the widget so that the button rebuilds
      await tester.pump();
// Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
        passwordEmpty,
      );
// Pump the widget so that the button rebuilds
      await tester.pump();
// Assert: check if the submit button is enabled
      final textField = tester.widget<TextField>(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      );
      final decoration = textField.decoration!;
      expect(decoration.errorText, 'Password cannot be empty');
    });

    testWidgets('Login username field is empty', (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();

// Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
        usernameCorrect,
      );
// Pump the widget so that the button rebuilds
      await tester.pump();
// Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
        usernameEmpty,
      );
// Pump the widget so that the button rebuilds
      await tester.pump();
// Assert: check if the submit button is enabled
      final textField = tester.widget<TextField>(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
      );
      final decoration = textField.decoration!;
      expect(decoration.errorText, 'Username cannot be empty');
    });
  });
}
