import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../constants.dart';
import '../../mock.dart';
import '../../test_dependency_injector.dart';

void main() {
  const screen = 'LogIn';
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen submit button is enabled with valid username and password',
      () {
    testWidgets(
        'Login submit button is enabled with valid username and password',
        (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();

      // Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
        usernameCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
        passwordCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Assert: check if the submit button is enabled
      final submitButton = tester.widget<TextButton>(
        find.byKey(logIn_submit_buttonWidgetKey),
      );
      expect(submitButton.enabled, isTrue);
    });
  });
}
