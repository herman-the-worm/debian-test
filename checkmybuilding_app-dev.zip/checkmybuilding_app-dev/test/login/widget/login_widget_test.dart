import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../constants.dart';
import '../../mock.dart';
import '../../test_dependency_injector.dart';

void main() {
  const screen = 'LogIn';
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen Button valid/invalid', () {
    testWidgets('Successful navigation to SignUp page',
        (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();

      // Assert: check if the submit button is enabled
      await tester.tap(
        find.byKey(logIn_goToSignUp_buttonWidgetKey),
      );

      await tester.pumpAndSettle();
      expect(find.byType(SignUpScreen), findsOneWidget);
    });
  });
}
