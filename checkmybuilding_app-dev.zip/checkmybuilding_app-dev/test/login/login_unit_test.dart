import 'package:bloc_test/bloc_test.dart';
import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:formz/formz.dart';
import 'package:mockito/mockito.dart';

import '../constants.dart';
import '../test_mocks/test_repository_mocks.mocks.dart';

void main() {
  const screen = 'LogIn';

  group('UsernameFieldValidator tests', () {
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty();
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty();
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty(null);
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
  });

  group('PasswordFieldValidator tests', () {
    test('Password should not be empty', () {
      const result = PasswordFieldModel.dirty();
      expect(result.error, PasswordFieldModelValidationError.empty);
    });
    test('Password should not be empty', () {
      const result = PasswordFieldModel.dirty();
      expect(result.error, PasswordFieldModelValidationError.empty);
    });
  });

  group('AuthRepository', () {
    // Mock repository
    late AuthenticationRepository mockAuthRepository;

    setUp(() {
      mockAuthRepository = MockAuthenticationRepository();
      when(
        mockAuthRepository.logIn(
          username: usernameCorrect,
          password: passwordCorrect,
        ),
      ).thenAnswer((_) async => true);
      when(
        mockAuthRepository.logIn(
          username: usernameIncorrect,
          password: passwordIncorrect,
        ),
      ).thenAnswer((_) async => false);
    });

    test('Successful authentication with correct credentials', () async {
      // Arrange

      // Act
      final result = await mockAuthRepository.logIn(
        username: usernameCorrect,
        password: passwordCorrect,
      );

      // Assert
      expect(result, isTrue);
    });

    test('Failure with incorrect credentials', () async {
      // Arrange

      // Act
      final result = await mockAuthRepository.logIn(
        username: usernameIncorrect,
        password: passwordIncorrect,
      );

      // Assert
      expect(result, isFalse);
    });
  });

  group('$screen Bloc correct/incorrect credentials', () {
    late LoginBloc loginBloc;
    late IAppAuthenticationRepository mockAuthRepository;

    setUp(() {
      mockAuthRepository = MockIAppAuthenticationRepository();
      loginBloc = LoginBloc(
        AuthenticationRepository(mockAuthRepository),
      );
      when(
        mockAuthRepository.logInWithEmailAndPassword(
          email: usernameCorrect,
          password: passwordCorrect,
        ),
      ).thenAnswer((_) async => const Right(true));
      when(
        mockAuthRepository.logInWithEmailAndPassword(
          email: usernameIncorrect,
          password: passwordIncorrect,
        ),
      ).thenAnswer(
        (_) async => const Left(
          AuthFailure.unauthorized(),
        ),
      );
    });
    blocTest<LoginBloc, LoginState>(
      'emits [LoginState] when username and passowrd are changed and valid',
      build: () => loginBloc,
      act: (bloc) => bloc
        ..add(const LoginEvent.loginFormUsernameChanged(usernameCorrect))
        ..add(const LoginEvent.loginFormPasswordChanged(passwordCorrect)),
      expect: () => [
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: LoginError.initial,
          isValid: false,
        ),
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: LoginError.initial,
          isValid: true,
        ),
      ],
    );
    blocTest<LoginBloc, LoginState>(
      'emits [LoginState] when username and passowrd are changed and not valid',
      build: () => loginBloc,
      act: (bloc) async {
        bloc
          ..add(const LoginEvent.loginFormUsernameChanged(''))
          ..add(const LoginEvent.loginFormPasswordChanged(''));
      },
      expect: () => [
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: LoginError.initial,
          isValid: false,
        ),
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(),
          passwordFieldModel: PasswordFieldModel.dirty(),
          error: LoginError.initial,
          isValid: false,
        ),
      ],
    );
    blocTest<LoginBloc, LoginState>(
      'emits [LoginState] when valid data is submitted'
      ' with correct credentials',
      build: () => loginBloc,
      act: (bloc) => bloc
        ..add(const LoginEvent.loginFormUsernameChanged(usernameCorrect))
        ..add(const LoginEvent.loginFormPasswordChanged(passwordCorrect))
        ..add(
          const LoginEvent.loginSubmitted(),
        ),
      expect: () => [
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: LoginError.initial,
          isValid: false,
        ),
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: LoginError.initial,
          isValid: true,
        ),
        const LoginState(
          status: FormzSubmissionStatus.inProgress,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: LoginError.initial,
          isValid: true,
        ),
        const LoginState(
          status: FormzSubmissionStatus.success,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: LoginError.initial,
          isValid: true,
        ),
      ],
      // verify: (_) async {
      //   verify(
      //     mockAuthenticationRepository.logIn(
      //       username: usernameCorrect,
      //       password: passwordCorrect,
      //     ),
      //   ).called(1);
      // },
    );
    blocTest<LoginBloc, LoginState>(
      'emits [LoginState] when valid data is submitted '
      'with incorrect credentials',
      build: () => loginBloc,
      setUp: () => when(
        mockAuthRepository.logInWithEmailAndPassword(
          email: usernameIncorrect,
          password: passwordIncorrect,
        ),
      ).thenAnswer(
        (_) async => const Left(
          AuthFailure.unauthorized(),
        ),
      ),
      act: (bloc) => bloc
        ..add(const LoginEvent.loginFormUsernameChanged(usernameIncorrect))
        ..add(const LoginEvent.loginFormPasswordChanged(passwordIncorrect))
        ..add(
          const LoginEvent.loginSubmitted(),
        ),
      expect: () => [
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: LoginError.initial,
          isValid: false,
        ),
        const LoginState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: LoginError.initial,
          isValid: true,
        ),
        const LoginState(
          status: FormzSubmissionStatus.inProgress,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: LoginError.initial,
          isValid: true,
        ),
        const LoginState(
          status: FormzSubmissionStatus.failure,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: LoginError.initial,
          isValid: true,
        ),
      ],
      // verify: (_) async {
      //   verify(
      //     mockAuthenticationRepository.logIn(
      //       username: usernameIncorrect,
      //       password: passwordIncorrect,
      //     ),
      //   ).called(1);
      // },
    );
  });
}
