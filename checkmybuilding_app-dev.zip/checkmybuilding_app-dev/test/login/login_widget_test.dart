import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter_test/flutter_test.dart';

import '../constants.dart';
import '../mock.dart';
import '../test_dependency_injector.dart';

void main() {
  const screen = 'LogIn';
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen Screen', () {
    testWidgets('renders initial AppPage and Login Page on top',
        (tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();
      expect(find.byType(LoginScreen), findsOneWidget);
      expect(find.byType(LoginFormSubmitButtonWidget), findsOneWidget);
      expect(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
        findsOneWidget,
      );
      expect(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
        findsOneWidget,
      );
      expect(find.byKey(logIn_goToSignUp_buttonWidgetKey), findsOneWidget);
      expect(find.byKey(logIn_submit_buttonWidgetKey), findsOneWidget);
      expect(
        find.byKey(logIn_formForgetPasswor_buttonWidgetKey),
        findsOneWidget,
      );
      expect(find.byKey(logIn_formTitleLogin_textWidgetKey), findsOneWidget);
      expect(find.byKey(logIn_divider_rowWidgetKey), findsOneWidget);
      expect(
        find.byKey(logIn_formDontHaveAnnyAcc_buttonWidgetKey),
        findsOneWidget,
      );
    });
  });
}
