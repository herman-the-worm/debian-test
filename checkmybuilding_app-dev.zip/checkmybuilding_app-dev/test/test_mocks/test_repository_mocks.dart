import 'package:checkmybuilding/shared/repository/app_authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/firebase_module.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/i_storage_repository.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks(
  [
    MockSpec<IAppAuthenticationRepository>(),
    MockSpec<AppAuthenticationRepository>(),
    MockSpec<AuthenticationRepository>(),
    MockSpec<IStorage>(),
    MockSpec<GoogleSignIn>(),
    MockSpec<FirebaseAuth>(),
    MockSpec<FirebaseModule>(),
  ],
)
void load() => debugPrint('loaded');
