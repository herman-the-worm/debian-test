import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/view/login_view.dart';
import 'package:checkmybuilding/components/template/view/template_view.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

import '../constants.dart';
import '../mock.dart';
import '../test_dependency_injector.dart';
import '../test_mocks/test_repository_mocks.mocks.dart';

void main() {
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  // setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('Successful navigation to template page', () {
    setUp(() {
      configureDependenciesTest();
      final AuthenticationRepository mockAuthRepository =
          MockAuthenticationRepository();
      when(
        mockAuthRepository.logIn(
          username: usernameCorrect,
          password: passwordCorrect,
        ),
      ).thenAnswer((_) async => true);
      if (getItTest.isRegistered<AuthenticationRepository>()) {
        debugPrint('unregistering AuthenticationRepository');
        getItTest.unregister<AuthenticationRepository>();
      }
      getItTest
          .registerSingleton<AuthenticationRepository>(mockAuthRepository); //
    });

    testWidgets('Successful navigation to template page',
        (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();
      expect(find.byType(LoginScreen), findsOneWidget);
      // Act: simulate user input
      await tester.enterText(
        find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
        usernameCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
        passwordCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();
      // Assert: check if the submit button is enabled
      // await tester.tap(
      //   find.byKey(logInGoToSignUpButtonKey),
      // );
      await tester.tap(
        find.byKey(logIn_submit_buttonWidgetKey),
      );
      await tester.pumpAndSettle();
      // tester.allWidgets.forEach((widget) {
      //   print(widget);
      // });

      expect(find.byType(HomeScreen), findsOneWidget);
      await tester.pumpAndSettle();
      expect(find.byKey(home_createNewAudit_buttonWidgetKey), findsOneWidget);

      await tester.tap(find.byKey(home_createNewAudit_buttonWidgetKey));
      await tester.pumpAndSettle();
      expect(find.byKey(homeState_showCustomDialog_WidgetKey), findsOneWidget);

      expect(
        find.byKey(homeState_showCustomDialog_useTemplate_buttonWidgetKey),
        findsOneWidget,
      );

      await tester.tap(
        find.byKey(homeState_showCustomDialog_useTemplate_buttonWidgetKey),
      );

      await tester.pumpAndSettle();
      expect(find.byType(TemplateScreen), findsOneWidget);
    });
  });
}
