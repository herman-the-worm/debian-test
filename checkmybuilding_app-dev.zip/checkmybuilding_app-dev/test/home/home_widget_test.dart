import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:flutter_test/flutter_test.dart';

import '../constants.dart';
import '../helpers/helpers.dart';
import '../mock.dart';
import '../test_dependency_injector.dart';

void main() {
  const screen = 'LogIn';
  setupFirebaseAuthMocks();

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen Screen', () {
    testWidgets('renders initial Home Page ', (tester) async {
      await tester.pumpApp(const HomeScreen());
      expect(find.byType(HomeScreen), findsOneWidget);
      await tester.pumpAndSettle();
      expect(find.byKey(home_createNewAudit_buttonWidgetKey), findsOneWidget);
      expect(find.byKey(home_celendarOfAudits_buttonWidgetKey), findsOneWidget);
      expect(find.byKey(home_iconsColumn_buttonsWidgetKey), findsOneWidget);
      expect(find.byKey(home_separatorWithText_widgetKey), findsOneWidget);
      expect(find.byKey(home_itemAudit_widgetKey), findsWidgets);
    });
  });

  testWidgets('Successful navigation to showDialog state',
      (WidgetTester tester) async {
    await tester.pumpApp(const HomeScreen());

    expect(find.byType(HomeScreen), findsOneWidget);
    await tester.pumpAndSettle();

    await tester.tap(
      find.byKey(home_createNewAudit_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(homeState_showCustomDialog_WidgetKey), findsOneWidget);
  });
}
