// ignore_for_file: cascade_invocations

import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/data_providers/cache_provider.dart';
import 'package:checkmybuilding/shared/repository/app_authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/base_repository.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/i_storage_repository.dart';
import 'package:checkmybuilding/shared/repository/secure_storage_repository.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get_it/get_it.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'test_mocks/test_repository_mocks.mocks.dart';

final getItTest = GetIt.instance;

void configureDependenciesTest() {
  // Services
  // getItTest.registerSingleton<DioClient>(DioClient());
  getItTest.registerSingleton<FirebaseAuth>(MockFirebaseAuth());
  getItTest.registerSingleton<GoogleSignIn>(GoogleSignIn());

  // Repositories
  getItTest.registerLazySingleton<IStorage>(SecureStorageRepository.new);
  getItTest.registerFactory<BaseRepository>(
    // ignore: unnecessary_lambdas
    () => BaseRepository(
        // getItTest<DioClient>()
        ),
  );
  getItTest.registerSingleton<IAppAuthenticationRepository>(
    AppAuthenticationRepository(
      // getItTest<DioClient>(),
      getItTest<IStorage>(),
      getItTest<FirebaseAuth>(),
      getItTest<GoogleSignIn>(),
      CacheClient(),
    ),
  );
  getItTest.registerSingleton<AuthenticationRepository>(
    AuthenticationRepository(
      getItTest<IAppAuthenticationRepository>(),
    ),
  );

  // Blocs
  getItTest.registerFactory<SignUpBloc>(
    () => SignUpBloc(
      getItTest<IAppAuthenticationRepository>(),
    ),
  );
  getItTest.registerFactory<LoginBloc>(
    () => LoginBloc(getItTest<AuthenticationRepository>()),
  );
  getItTest.registerSingleton<AuthenticationBloc>(
    AuthenticationBloc(
      authenticationRepository: getItTest<AuthenticationRepository>(),
    ),
  );
}
