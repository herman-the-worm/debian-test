import 'package:bloc_test/bloc_test.dart';
import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/shared/models/auth_failure_model/auth_failure_model.dart';
import 'package:checkmybuilding/shared/models/field_models/password_field_model.dart';
import 'package:checkmybuilding/shared/models/field_models/user_data_field_model.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:formz/formz.dart';
import 'package:mockito/mockito.dart';

import '../constants.dart';
import '../mock.dart';
import '../test_mocks/test_repository_mocks.mocks.dart';

void main() {
  setupFirebaseAuthMocks();

  const screen = 'SignUp';

  setUpAll(setUpGlobal);

  group('UsernameFieldValidator tests', () {
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty();
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty();
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
    test('Username should not be empty', () {
      const result = UsernameDataFieldModel.dirty(null);
      expect(result.error, UsernameDataFieldModelValidationError.empty);
    });
  });
  group('PasswordFieldValidator tests', () {
    test('Password should not be empty', () {
      const result = PasswordFieldModel.dirty();
      expect(result.error, PasswordFieldModelValidationError.empty);
    });
    test('Password should not be empty', () {
      const result = PasswordFieldModel.dirty();
      expect(result.error, PasswordFieldModelValidationError.empty);
    });
  });
  group('AuthRepository', () {
    // Mock repository
    late IAppAuthenticationRepository mockAuthRepository;

    setUp(() {
      mockAuthRepository = MockIAppAuthenticationRepository();
      when(
        mockAuthRepository.signUp(
          email: usernameCorrect,
          password: passwordCorrect,
        ),
      ).thenAnswer((_) async => const Right(true));
      when(
        mockAuthRepository.signUp(
          email: usernameIncorrect,
          password: passwordIncorrect,
        ),
      ).thenAnswer(
        (_) async => const Left(
          AuthFailure.unauthorized(),
        ),
      );
    });

    test('Successful signUp with correct credentials', () async {
      // Arrange

      // Act
      final result = await mockAuthRepository.signUp(
        email: usernameCorrect,
        password: passwordCorrect,
      );

      // Assert
      expect(result.isRight(), isTrue);
    });

    test('Failure with incorrect credentials', () async {
      // Arrange

      // Act
      final result = await mockAuthRepository.signUp(
        email: usernameIncorrect,
        password: passwordIncorrect,
      );

      // Assert
      expect(result.isRight(), isFalse);
    });
  });
  group('$screen Bloc correct/incorrect credentials', () {
    late SignUpBloc signUpBloc;
    late IAppAuthenticationRepository mockAuthRepository;

    setUp(() {
      mockAuthRepository = MockIAppAuthenticationRepository();
      signUpBloc = SignUpBloc(mockAuthRepository);
    });
    blocTest<SignUpBloc, SignUpState>(
      'emits [SignUpState] when username and passowrd are changed and valid',
      build: () => signUpBloc,
      act: (bloc) => bloc
        ..add(const SignUpEvent.signUpFormUsernameChanged(usernameCorrect))
        ..add(const SignUpEvent.signUpFormPasswordChanged(passwordCorrect)),
      expect: () => [
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: SignUpError.initial,
          isValid: false,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
      ],
    );
    blocTest<SignUpBloc, SignUpState>(
      'emits [SignUpState] when username and passowrd are not valid',
      build: () => signUpBloc,
      act: (bloc) async {
        bloc
          ..add(const SignUpEvent.signUpFormUsernameChanged(''))
          ..add(const SignUpEvent.signUpFormPasswordChanged(''));
      },
      expect: () => [
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: SignUpError.initial,
          isValid: false,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(),
          passwordFieldModel: PasswordFieldModel.dirty(),
          error: SignUpError.initial,
          isValid: false,
        ),
      ],
    );
    blocTest<SignUpBloc, SignUpState>(
      'emits [SignUpState] when valid data is submitted'
      ' with correct credentials',
      setUp: () {
        when(
          mockAuthRepository.signUp(
            email: usernameCorrect,
            password: passwordCorrect,
          ),
        ).thenAnswer((_) async => const Right(true));
      },
      build: () => signUpBloc,
      act: (bloc) => bloc
        ..add(const SignUpEvent.signUpFormUsernameChanged(usernameCorrect))
        ..add(const SignUpEvent.signUpFormPasswordChanged(passwordCorrect))
        ..add(
          const SignUpEvent.signUpSubmitted(),
        ),
      expect: () => [
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: SignUpError.initial,
          isValid: false,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.inProgress,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.success,
          usernameDataFieldModel: UsernameDataFieldModel.dirty(usernameCorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordCorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
      ],
    );
    blocTest<SignUpBloc, SignUpState>(
      'emits [SignUpState] when valid data is submitted '
      'with incorrect credentials',
      build: () => signUpBloc,
      setUp: () {
        when(
          mockAuthRepository.signUp(
            email: usernameIncorrect,
            password: passwordIncorrect,
          ),
        ).thenAnswer(
          (_) async => const Left(
            AuthFailure.unauthorized(),
          ),
        );
      },
      act: (bloc) => bloc
        ..add(const SignUpEvent.signUpFormUsernameChanged(usernameIncorrect))
        ..add(const SignUpEvent.signUpFormPasswordChanged(passwordIncorrect))
        ..add(
          const SignUpEvent.signUpSubmitted(),
        ),
      expect: () => [
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.pure(),
          error: SignUpError.initial,
          isValid: false,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.initial,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.inProgress,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
        const SignUpState(
          status: FormzSubmissionStatus.failure,
          usernameDataFieldModel:
              UsernameDataFieldModel.dirty(usernameIncorrect),
          passwordFieldModel: PasswordFieldModel.dirty(passwordIncorrect),
          error: SignUpError.initial,
          isValid: true,
        ),
      ],
    );
  });
}
