import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import '../constants.dart';
import '../helpers/helpers.dart';
import '../mock.dart';
import '../test_dependency_injector.dart';

void main() {
  setupFirebaseAuthMocks();

  const screen = 'SignUp';

  setUpAll(setUpGlobal);

  setUp(configureDependenciesTest);

  tearDown(getItTest.reset);

  group('$screen Screen', () {
    testWidgets('renders SignUp on top', (tester) async {
      await tester.pumpApp(const SignUpScreen());

      expect(find.byType(SignUpScreen), findsOneWidget);
      // await tester.pumpWidget(const SignUpScreen());
      expect(find.byType(SignUpScreen), findsOneWidget);
      expect(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
        findsOneWidget,
      );
      expect(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        findsOneWidget,
      );
      expect(find.byKey(signUp_submit_buttonWidgetKey), findsOneWidget);
      expect(
        find.byKey(signUp_formAlreadyHaveAnAcc_buttonWidgetKey),
        findsOneWidget,
      );
      expect(find.byKey(signUp_formTitleSignUp_textWidgetKey), findsOneWidget);
      expect(find.byKey(logIn_divider_rowWidgetKey), findsOneWidget);
    });
  });

  group('$screen Page wrong username/password input', () {
    testWidgets('$screen password field is empty', (WidgetTester tester) async {
      await tester.pumpApp(const SignUpScreen());

      expect(find.byType(SignUpScreen), findsOneWidget);
      await tester.pumpAndSettle();

      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        passwordCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pump();
      await tester.enterText(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
        passwordCorrect,
      );
      await tester.pump();
      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
        passwordEmpty,
      );
      // Pump the widget so that the button rebuilds
      await tester.pump();
      // Assert: check if the submit button is enabled
      final textField = tester.widget<TextField>(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
      );
      final decoration = textField.decoration!;
      expect(decoration.errorText, 'Password cannot be empty');
    });
    testWidgets('$screen username field is empty', (WidgetTester tester) async {
      await tester.pumpApp(const SignUpScreen());

      expect(find.byType(SignUpScreen), findsOneWidget);

      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        usernameCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pump();
      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        usernameEmpty,
      );
      // Pump the widget so that the button rebuilds
      await tester.pump();
      // Assert: check if the submit button is enabled
      final textField = tester.widget<TextField>(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
      );
      final decoration = textField.decoration!;
      expect(decoration.errorText, 'Username cannot be empty');
    });
  });
  group('$screen Button valid/invalid', () {
    testWidgets('$screen button is enabled with valid username and password',
        (WidgetTester tester) async {
      await tester.pumpApp(const SignUpScreen());

      expect(find.byType(SignUpScreen), findsOneWidget);
      await tester.pumpAndSettle();

      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        usernameCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
        passwordCorrect,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Assert: check if the submit button is enabled
      final submitButton = tester.widget<TextButton>(
        find.byKey(signUp_submit_buttonWidgetKey),
      );
      expect(submitButton.enabled, isTrue);
    });
    testWidgets(
        '$screen submit button is disabled with invalid username and password',
        (WidgetTester tester) async {
      await tester.pumpApp(const SignUpScreen());

      expect(find.byType(SignUpScreen), findsOneWidget);
      await tester.pumpAndSettle();

      // Act: simulate user input
      await tester.enterText(
        find.byKey(signUp_usernameInput_textFieldWidgetKey),
        usernameEmpty,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(signUp_passwordInput_textFieldWidgetKey),
        passwordEmpty,
      );
      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Pump the widget so that the button rebuilds
      await tester.pumpAndSettle();

      // Assert: check if the submit button is enabled
      final submitButton = tester.widget<TextButton>(
        find.byKey(signUp_submit_buttonWidgetKey),
      );
      expect(submitButton.enabled, isFalse);
    });

    testWidgets('Successful navigation to LogIn page',
        (WidgetTester tester) async {
      await tester.pumpWidget(const App());

      expect(find.byType(App), findsOneWidget);
      await tester.pumpAndSettle();

      // Assert: check if the submit button is enabled
      await tester.tap(
        find.byKey(logIn_goToSignUp_buttonWidgetKey),
      );

      await tester.pumpAndSettle();
      expect(find.byType(SignUpScreen), findsOneWidget);

      // Assert: check if the submit button is enabled
      await tester.tap(
        find.byKey(signUp_goToLogIn_buttonWidgetKey),
      );

      await tester.pumpAndSettle();
      expect(find.byType(LoginScreen), findsOneWidget);
    });
  });
}
