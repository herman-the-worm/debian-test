package com.codinghouse.checkmybuilding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
