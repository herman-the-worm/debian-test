import 'dart:math';

import 'package:checkmybuilding/firebase_options_development.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
// ignore: depend_on_referenced_packages
import 'package:flutter_web_plugins/url_strategy.dart' show usePathUrlStrategy;

const String usernameCorrectIntegrationTest = 'andreytest@gmail.com';
const String passwordCorrectIntegrationTest = 'qwerty';
String randomUsername = generateRandomUsername();
String randomPassword = 'qwerty';

Future<void> setUpGlobalIntegration() async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  if (kIsWeb) {
    usePathUrlStrategy();
  }

  // FlutterError.onError = (details) {
  //   dev.log(details.exceptionAsString(), stackTrace: details.stack);
  // };
  //
  // Bloc.observer = const AppBlocObserver();

  configureDependencies();
}

String generateRandomUsername() {
  final timestamp = DateTime.now().millisecondsSinceEpoch;
  final randomNumber = Random().nextInt(100000);
  const salt = 'MyApp'; // Replace with your desired salt

  return '$timestamp$randomNumber$salt@test.com';
}
