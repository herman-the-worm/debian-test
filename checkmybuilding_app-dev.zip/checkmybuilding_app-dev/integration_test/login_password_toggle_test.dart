import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('login password view/unview', (tester) async {
    await tester.pumpWidget(const App());
    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
    await tester.pumpAndSettle();
    expect(
      find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      findsOneWidget,
    );
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      passwordCorrectIntegrationTest,
    );
    await tester.pumpAndSettle();
    final toggleButton = find.byIcon(Icons.visibility_off);
    expect(toggleButton, findsOneWidget);
    await tester.tap(toggleButton);
    await tester.pump();
    final newToggleButton = find.byIcon(Icons.visibility);
    expect(newToggleButton, findsOneWidget);
  });
}
