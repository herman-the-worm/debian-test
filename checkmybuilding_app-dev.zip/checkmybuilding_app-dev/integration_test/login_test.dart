import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('app test', (tester) async {
    await tester.pumpWidget(const App());
    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    await tester.enterText(
      find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
      usernameCorrectIntegrationTest,
    );
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      passwordCorrectIntegrationTest,
    );

    await tester.pumpAndSettle();
    //
    await tester.tap(
      find.byKey(logIn_submit_buttonWidgetKey),
    );
    // await tester.tap(find.byKey(logInGoToSignUpButtonKey));
    await tester.pumpAndSettle();
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(find.byType(SnackBar), findsOneWidget);
    expect(
      find.byKey(home_logOutButton_widgetKey),
      findsOneWidget,
    );
    getIt.get<AuthenticationBloc>().add(AuthenticationLogoutRequested());
    // final logOutButton = find.byKey(home_logOutButton_widgetKey);
    // await tester.tap(logOutButton);
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
  });
}
