import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/view/login_view.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('Home scroling elements', (tester) async {
    await tester.pumpWidget(const App());
    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    await tester.enterText(
      find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
      usernameCorrectIntegrationTest,
    );
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      passwordCorrectIntegrationTest,
    );
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(logIn_submit_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(find.byKey(home_itemAudit_widgetKey), findsWidgets);
    await tester.pumpAndSettle();
    final lastItem = find.byKey(
      home_itemAuditLast_widgetKey,
    );
    await tester.scrollUntilVisible(
      lastItem,
      500,
      scrollable: find.byType(Scrollable),
    );
    await tester.pumpAndSettle();
    expect(lastItem, findsOneWidget);
  });
}
