import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/view/login_view.dart';
import 'package:checkmybuilding/components/template/view/template_view.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('Show dialog is opened and navigation to template page',
      (tester) async {
    await tester.pumpWidget(const App());
    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    await tester.enterText(
      find.byKey(logIn_formUsernameInput_textFieldWidgetKey),
      usernameCorrectIntegrationTest,
    );
    await tester.pumpAndSettle();

    await tester.enterText(
      find.byKey(logIn_formPasswordInput_textFieldWidgetKey),
      passwordCorrectIntegrationTest,
    );

    await tester.pumpAndSettle();
    //
    await tester.tap(
      find.byKey(logIn_submit_buttonWidgetKey),
    );
    // await tester.tap(find.byKey(logInGoToSignUpButtonKey));
    await tester.pumpAndSettle();
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(find.byKey(home_itemAudit_widgetKey), findsWidgets);
    expect(find.byKey(home_createNewAudit_buttonWidgetKey), findsOneWidget);
    await tester.tap(
      find.byKey(home_createNewAudit_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(homeState_showCustomDialog_WidgetKey), findsOneWidget);

    expect(
      find.byKey(homeState_showCustomDialog_useTemplate_buttonWidgetKey),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(homeState_showCustomDialog_useTemplate_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byType(TemplateScreen), findsOneWidget);
  });
}
