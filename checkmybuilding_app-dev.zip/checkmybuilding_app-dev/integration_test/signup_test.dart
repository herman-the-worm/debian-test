import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/view/login_view.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('signUp test', (tester) async {
    await tester.pumpWidget(const App());

    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.byKey(logIn_goToSignUp_buttonWidgetKey), findsOneWidget);
    // Assert: check if the submit button is enabled
    await tester.tap(
      find.byKey(logIn_goToSignUp_buttonWidgetKey),
    );

    await tester.pumpAndSettle();
    expect(find.byType(SignUpScreen), findsOneWidget);
    await tester.enterText(
      find.byKey(
        signUp_usernameInput_textFieldWidgetKey,
      ),
      randomUsername,
    );
    await tester.pumpAndSettle();
    await tester.enterText(
      find.byKey(signUp_passwordInput_textFieldWidgetKey),
      randomPassword,
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(signUp_submit_buttonWidgetKey));
    await tester.pumpAndSettle();
    if (kIsWeb) {
      // ignore: inference_failure_on_instance_creation
      await Future.delayed(const Duration(seconds: 2));
      await tester.pumpAndSettle();
    }
    //
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(find.byType(SnackBar), findsOneWidget);
  });
}
