import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/login/view/login_view.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);
  testWidgets('navigation to login page', (tester) async {
    await tester.pumpWidget(const App());
    await tester.pumpAndSettle();
    expect(find.byType(App), findsOneWidget);
    expect(find.byType(LoginScreen), findsOneWidget);
    expect(find.byKey(logIn_goToSignUp_buttonWidgetKey), findsOneWidget);
    await tester.tap(
      find.byKey(logIn_goToSignUp_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byType(SignUpScreen), findsOneWidget);
    expect(find.byKey(signUp_goToLogIn_buttonWidgetKey), findsOneWidget);
    await tester.tap(
      find.byKey(signUp_goToLogIn_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byType(LoginScreen), findsOneWidget);
  });
}
