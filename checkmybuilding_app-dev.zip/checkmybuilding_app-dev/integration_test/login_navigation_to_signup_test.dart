import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

import 'constants.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  // This is run before all tests
  setUpAll(setUpGlobalIntegration);

  tearDownAll(getIt.reset);

  testWidgets('navigation to signUp', (tester) async {
    await tester.pumpWidget(const App());
    expect(find.byType(App), findsOneWidget);
    await tester.pumpAndSettle();

    expect(find.byType(LoginScreen), findsOneWidget);
    await tester.pumpAndSettle();
    expect(find.byKey(logIn_goToSignUp_buttonWidgetKey), findsOneWidget);
    await tester.pumpAndSettle();
    await tester.tap(
      find.byKey(logIn_goToSignUp_buttonWidgetKey),
    );
    await tester.pumpAndSettle();
    expect(find.byType(SignUpScreen), findsOneWidget);
  });
}
