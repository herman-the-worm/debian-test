import 'dart:async';
import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/models/user_model.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:equatable/equatable.dart';
import 'package:injectable/injectable.dart';

part 'authentication_event.dart';
part 'authentication_state.dart';

@Singleton()
class AuthenticationBloc
    extends Bloc<AuthenticationEvent, AuthenticationState> {
  AuthenticationBloc({
    required this.authenticationRepository,
  }) : super(
          authenticationRepository.currentUser.isNotEmpty
              ? const AuthenticationState.authenticated()
              : const AuthenticationState.unknown(),
        ) {
    on<AuthenticationStatusChanged>(_onAuthenticationStatusChanged);
    on<AuthenticationLogoutRequested>(_onAuthenticationLogoutRequested);
    on<AuthenticationInitialized>(_onAuthenticationInitialized);
    on<_AppUserChanged>(_onUserChanged);
  }

  final AuthenticationRepository authenticationRepository;
  late StreamSubscription<AuthenticationStatus>
      authenticationStatusSubscription;
  static const String tokenKey = authTokenKey;

  @override
  Future<void> close() {
    authenticationStatusSubscription.cancel();
    authenticationRepository.dispose();
    return super.close();
  }

  Future<void> _onAuthenticationStatusChanged(
    AuthenticationStatusChanged event,
    Emitter<AuthenticationState> emit,
  ) async {
    log('AuthenticationStatusChanged: ${event.status}');
    switch (event.status) {
      case AuthenticationStatus.unauthenticated:
        return emit(const AuthenticationState.unauthenticated());
      case AuthenticationStatus.authenticated:
        return emit(const AuthenticationState.authenticated());
      case AuthenticationStatus.unknown:
        return emit(const AuthenticationState.unknown());
    }
  }

  Future<void> _onAuthenticationLogoutRequested(
    AuthenticationLogoutRequested event,
    Emitter<AuthenticationState> emit,
  ) async {
    await authenticationRepository.logOut();
  }

  Future<void> _onAuthenticationInitialized(
    AuthenticationInitialized event,
    Emitter<AuthenticationState> emit,
  ) async {
    authenticationStatusSubscription = authenticationRepository.status.listen(
      (status) => add(AuthenticationStatusChanged(status)),
    );
  }

  void _onUserChanged(
    _AppUserChanged event,
    Emitter<AuthenticationState> emit,
  ) {
    emit(const AuthenticationState.authenticated());
  }
}
