// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:checkmybuilding/components/login/bloc/login_bloc.dart' as _i15;
import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart'
    as _i13;
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart'
    as _i16;
import 'package:checkmybuilding/shared/data_providers/cache_provider.dart'
    as _i4;
import 'package:checkmybuilding/shared/repository/app_authentication_repository.dart'
    as _i12;
import 'package:checkmybuilding/shared/repository/authentication_repository.dart'
    as _i14;
import 'package:checkmybuilding/shared/repository/base_repository.dart' as _i3;
import 'package:checkmybuilding/shared/repository/firebase_authentication_repository.dart'
    as _i8;
import 'package:checkmybuilding/shared/repository/firebase_module.dart' as _i17;
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart'
    as _i11;
import 'package:checkmybuilding/shared/repository/i_firebase_authentication_repository.dart'
    as _i7;
import 'package:checkmybuilding/shared/repository/i_storage_repository.dart'
    as _i9;
import 'package:checkmybuilding/shared/repository/secure_storage_repository.dart'
    as _i10;
import 'package:firebase_auth/firebase_auth.dart' as _i5;
import 'package:get_it/get_it.dart' as _i1;
import 'package:google_sign_in/google_sign_in.dart' as _i6;
import 'package:injectable/injectable.dart' as _i2;

extension GetItInjectableX on _i1.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i1.GetIt init({
    String? environment,
    _i2.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i2.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    final firebaseModule = _$FirebaseModule();
    gh.factory<_i3.BaseRepository>(() => _i3.BaseRepository());
    gh.factory<_i4.CacheClient>(() => _i4.CacheClient());
    gh.singleton<_i5.FirebaseAuth>(firebaseModule.firebaseAuth);
    gh.singleton<_i6.GoogleSignIn>(firebaseModule.googleSignIn);
    gh.singleton<_i7.IFirebaseAuth<dynamic, dynamic>>(
        _i8.FirebaseAuthService());
    gh.lazySingleton<_i9.IStorage>(() => _i10.SecureStorageRepository());
    gh.singleton<_i11.IAppAuthenticationRepository>(
        _i12.AppAuthenticationRepository(
      gh<_i9.IStorage>(),
      gh<_i5.FirebaseAuth>(),
      gh<_i6.GoogleSignIn>(),
      gh<_i4.CacheClient>(),
    ));
    gh.factory<_i13.SignUpBloc>(
        () => _i13.SignUpBloc(gh<_i11.IAppAuthenticationRepository>()));
    gh.singleton<_i14.AuthenticationRepository>(
        _i14.AuthenticationRepository(gh<_i11.IAppAuthenticationRepository>()));
    gh.factory<_i15.LoginBloc>(
        () => _i15.LoginBloc(gh<_i14.AuthenticationRepository>()));
    gh.singleton<_i16.AuthenticationBloc>(_i16.AuthenticationBloc(
        authenticationRepository: gh<_i14.AuthenticationRepository>()));
    return this;
  }
}

class _$FirebaseModule extends _i17.FirebaseModule {}
