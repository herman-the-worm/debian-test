import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class SizedBoxStatic {
  static const SizedBox kHeightSizedBoxL = SizedBox(
    height: kPixelSizeL,
  );
  static const SizedBox kHeightSizedBoxM = SizedBox(
    height: kPixelSizeM,
  );
  static const SizedBox kHeightSizedBoxS = SizedBox(
    height: kPixelSizeS,
  );

  static const SizedBox kHeightSizedBoxXS = SizedBox(
    height: kPixelSizeXS,
  );

  static const SizedBox kWidthSizedBoxL = SizedBox(
    width: kPixelSizeL,
  );
  static const SizedBox kWidthSizedBoxM = SizedBox(
    width: kPixelSizeM,
  );
  static const SizedBox kWidthSizedBoxS = SizedBox(
    width: kPixelSizeS,
  );

  static const SizedBox kWidthSizedBoxXS = SizedBox(
    width: kPixelSizeXS,
  );
}

class KPaddingSizeStatic {
  static const kPaddingSizeXXS = 2.0;
  static const kPaddingSizeXS = 5.0;
  static const kPaddingSizeS = 10.0;
  static const kPaddingSizeXSS = 7.5;
  static const kPaddingSizeSM = 15.0;
  static const kPaddingSizeM = 20.0;
  static const kPaddingSizeL = 40.0;
  static const kPaddingSizeML = 25.0;
  static const kPaddingSizeXL = 50.0;
  static const kPaddingSizeXXL = 75.0;
}

const SizedBox kSizedBoxM = SizedBox(
  height: kPixelSizeM,
  width: kPixelSizeM,
);

const SizedBox kTinySizedBox = SizedBox(
  width: kPixelSizeXS,
  height: kPixelSizeXS,
);

Divider dividerWidget({Color? color, double? thickness, double? height}) {
  return Divider(
    color: color,
    thickness: thickness ?? 1,
    height: height ?? 1,
  );
}

OutlineInputBorder chatScreenOutlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.circular(KPaddingSizeStatic.kPaddingSizeXS),
  borderSide: const BorderSide(
    color: KCustomColorTheme.kDarkGrey,
  ),
);

class NoAnimationPageTransitionsBuilder extends PageTransitionsBuilder {
  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    // Return the child without any transitions/animations
    return child;
  }
}
