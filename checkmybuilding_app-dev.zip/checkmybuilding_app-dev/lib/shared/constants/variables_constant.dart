import 'package:flutter/foundation.dart';

/// Backend related
const String backendString = '';
const String backendStringFake = '';
const String authTokenKey = 'AUTH_TOKEN';
const String usernameToken = 'USERNAME_TOKEN';

/// Other screen labels
const screenLabelError = 'Error';

/// UI related sizes
const kPixelSizeXS = 3.0;
const kPixelSizeS = 10.0;
const kPixelSizeM = 30.0;
const kPixelSizeL = 60.0;

/// Font Size
const kFontSizeXS = 6.0;
const kFontSizeS = 10.0;
const kFontSize12 = 12.0;
const kFontSizeM = 14.0;
const kFontSizeL = 18.0;
const kFontSizeXL = 24.0;
const kFontSizeXXL = 30.0;

/// Icon Size
const kIconSizeXS = 10.0;
const kIconSizeS = 15.0;
const kIconSizeM = 20.0;
const kIconSizeMM = 25.0;
const kIconSizeL = 30.0;
const kIconSizeXL = 50.0;
const kIconSizeXXL = 65.0;

// Widget params
const kWidgetWidthXXL = 300.0;
const kWidgetWidthXL = 150.0;
const kWidgetHeightM = 50.0;
const kWidgetWidthM = 50.0;
const kWidgetWidthS = 30.0;

/// Sized box size
const kSizedBoxSizeXS = 2.0;
const kSizedBoxSizeS = 5.0;
const kSizedBoxSizeM = 10.0;
const kSizedBoxSizeL = 15.0;

/// Border Side Size
const kBorderSideSize = 2.0;
const kBorderSideSizeM = 15.0;
const kBorderSideSizeL = 15.0;

// constraints
const maxWidthLarge = 1000.0;

/// Mobile scanner box height
const kMobileScannerBoxHeight = 450.0;

const String dateFormatMessage = 'MMMM dd, yyyy - h:mma ';

final bool isWebMobile = kIsWeb &&
    (defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS);
