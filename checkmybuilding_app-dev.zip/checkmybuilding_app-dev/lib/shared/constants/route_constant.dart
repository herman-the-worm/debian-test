class RouteItem {
  const RouteItem({required this.path, required this.name});
  final String path;
  final String name;
}

class KRouteStatic {
  static const RouteItem home = RouteItem(path: '/', name: 'Home');
  static const RouteItem login = RouteItem(path: '/login', name: 'Login');
  static const RouteItem signUp = RouteItem(path: '/sign-up', name: 'Sign Up');
  static const RouteItem template =
      RouteItem(path: '/template', name: 'Template');
  static const RouteItem logOut = RouteItem(path: '/login', name: 'Log Out');
  static const RouteItem profile = RouteItem(path: '/', name: 'Profile');
  static const RouteItem support = RouteItem(path: '/support', name: 'Support');
}
