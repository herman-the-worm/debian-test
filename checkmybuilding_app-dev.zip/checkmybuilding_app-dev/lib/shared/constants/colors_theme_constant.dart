import 'package:flutter/material.dart';

class KCustomColorTheme {
  static const Color kGreyMain = Color.fromRGBO(217, 217, 217, 1);
  static const Color kAppBarColor = Color.fromRGBO(26, 224, 255, 1);
  static const Color disabledColorButton = Colors.blueGrey;
  static const Color kBottomSheetBackground = Color.fromRGBO(26, 224, 255, 1);
  static const Color kSuccessPopUp = Color.fromRGBO(62, 226, 144, 1);
  static const Color kCompletedLight = Color.fromRGBO(230, 230, 230, 1);
  static const Color kPrimaryColor = Color.fromRGBO(59, 204, 68, 1);
  static const Color kSecondaryColor = Color.fromRGBO(33, 180, 219, 1);
  static const Color kGreen = Color.fromRGBO(0, 166, 90, 1);
  static const Color kLightGreen = Color(0xFFEBFDEB);
  static const Color kRed = Color.fromRGBO(225, 90, 118, 1);
  static const Color kLightRed = Color.fromRGBO(255, 238, 241, 1);
  static const Color kBlack = Color.fromRGBO(12, 13, 11, 1);
  static const Color kWhite = Color.fromRGBO(255, 255, 255, 1);
  static const Color kOrange = Color.fromRGBO(255, 182, 35, 1);
  static const Color kLightOrange = Color.fromRGBO(255, 248, 232, 1);
  static const Color kDisabledColor = Colors.blueGrey;
  static const Color kLightGrey = Color(0xFFA6A6A6);
  static const Color kGrey = Color.fromRGBO(217, 220, 223, 1);
  static const Color kDarkGrey = Color.fromRGBO(182, 182, 181, 1);
  static const Color kBlueChat = Color(0xFF3C8DBC);
  static const Color kLightBlue = Color(0xFF00AAFF);
  static const Color kGold = Color.fromRGBO(239, 208, 147, 1);
  static const Color kBlue = Color(0xFF2EAFEA);
  static const Color kTransparent = Colors.transparent;
  static const Color kBlackWithOpacity = Color(0x66000000);
}
