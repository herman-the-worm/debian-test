import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:flutter/material.dart';

ThemeData themeData = ThemeData(
  primaryColor: KCustomColorTheme.kPrimaryColor,
  scaffoldBackgroundColor: KCustomColorTheme.kWhite,
  appBarTheme: const AppBarTheme(
    centerTitle: true,
    titleTextStyle: TextStyle(
      color: KCustomColorTheme.kBlue,
      fontSize: kFontSizeXXL,
      letterSpacing: 1.5,
    ),
    backgroundColor: KCustomColorTheme.kAppBarColor,
    elevation: 0,
  ),
  iconButtonTheme: IconButtonThemeData(
    style: ButtonStyle(
      backgroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
      foregroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
      overlayColor: MaterialStateProperty.all<Color>(Colors.transparent),
    ),
  ),
  useMaterial3: true,
  buttonTheme: ButtonThemeData(
    colorScheme: ColorScheme.fromSwatch(
      backgroundColor: KCustomColorTheme.kGreen,
    ),
  ),
  textTheme: const TextTheme(
    displayLarge: TextStyle(
      fontSize: kFontSizeXL,
      color: KCustomColorTheme.kPrimaryColor,
      fontWeight: FontWeight.bold,
    ),
    displayMedium: TextStyle(
      fontSize: kFontSizeXL,
      color: KCustomColorTheme.kWhite,
    ),
    displaySmall: TextStyle(
      fontSize: kFontSizeL,
      fontWeight: FontWeight.w500,
      color: KCustomColorTheme.kWhite,
    ),
    headlineMedium: TextStyle(
      fontSize: kFontSizeL,
      fontWeight: FontWeight.bold,
      color: KCustomColorTheme.kPrimaryColor,
    ),
    headlineSmall: TextStyle(
      fontSize: kFontSizeL,
      fontWeight: FontWeight.w500,
      color: KCustomColorTheme.kBlack,
    ),
    // Title for text fields
    titleLarge: TextStyle(
      color: KCustomColorTheme.kWhite,
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w400,
    ),
    bodyLarge: TextStyle(
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w400,
      color: KCustomColorTheme.kGrey,
    ),
    bodyMedium: TextStyle(
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w400,
      color: KCustomColorTheme.kBlack,
    ),
    labelLarge: TextStyle(
      fontSize: kFontSizeXL,
      fontWeight: FontWeight.w500,
      color: KCustomColorTheme.kWhite,
    ),
    titleMedium: TextStyle(
      fontWeight: FontWeight.w400,
      color: KCustomColorTheme.kBlack,
      fontSize: kFontSizeM,
    ),
    titleSmall: TextStyle(
      fontWeight: FontWeight.w400,
      color: KCustomColorTheme.kBlack,
      fontSize: kFontSizeS,
    ),
  ),
);

ButtonStyle buttonStylePrimary = ButtonStyle(
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(50),
    ),
  ),
  backgroundColor: MaterialStateProperty.resolveWith(
    (states) {
      if (states.contains(MaterialState.pressed)) {
        return KCustomColorTheme.kPrimaryColor;
      } else if (states.contains(MaterialState.disabled)) {
        return KCustomColorTheme.kDisabledColor;
      }
      return KCustomColorTheme.kPrimaryColor;
    },
  ),
  elevation: MaterialStateProperty.all(0),
);

ButtonStyle buttonStyleSecondary = ButtonStyle(
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(50),
    ),
  ),
  backgroundColor: MaterialStateProperty.resolveWith(
    (states) {
      if (states.contains(MaterialState.pressed)) {
        return KCustomColorTheme.kDisabledColor;
      } else if (states.contains(MaterialState.disabled)) {
        return KCustomColorTheme.kDisabledColor;
      }
      return Colors.black;
    },
  ),
  elevation: MaterialStateProperty.all(0),
);

ButtonStyle buttonStyleBlack = ButtonStyle(
  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
    RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(50),
    ),
  ),
  backgroundColor: MaterialStateProperty.resolveWith(
    (states) {
      if (states.contains(MaterialState.pressed)) {
        return Colors.black;
      } else if (states.contains(MaterialState.disabled)) {
        return Colors.black;
      }
      return Colors.black;
    },
  ),
  elevation: MaterialStateProperty.all(0),
);

const noBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(
    Radius.circular(
      50,
    ),
  ),
  borderSide: BorderSide.none,
);

const border = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(50)),
);
