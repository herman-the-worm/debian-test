import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:flutter/material.dart';

double hintSize = 14;

extension CustomTextTheme on TextTheme {
  TextStyle get inputTitleTextStyle {
    return const TextStyle(
      color: KCustomColorTheme.kWhite,
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w400,
    );
  }

  TextStyle get errorTextStyle {
    return const TextStyle(
      color: KCustomColorTheme.kRed,
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w200,
    );
  }

  TextStyle get buttonTextStyle {
    return const TextStyle(
      fontSize: kFontSizeM,
      fontWeight: FontWeight.w500,
      color: KCustomColorTheme.kWhite,
    );
  }
}

class KCustomTextTheme {
  static const TextStyle textStyleBlackMain = TextStyle(
    color: KCustomColorTheme.kBlack,
    fontSize: kFontSizeM,
    fontWeight: FontWeight.w400,
  );

  static const TextStyle textStyleWhiteLarge = TextStyle(
    color: KCustomColorTheme.kWhite,
    // fontSize: kFontSizeM,
    // fontWeight: FontWeight.w200,
  );

  static const TextStyle textAccentButtonStyle = TextStyle(
    color: KCustomColorTheme.kBlue,
    fontSize: kFontSizeM,
    fontWeight: FontWeight.w400,
  );
  static const TextStyle textSquareButtonStyle = TextStyle(
    color: KCustomColorTheme.kBlack,
    fontSize: kFontSize12,
    fontWeight: FontWeight.w400,
  );
  static const TextStyle textStyleBlackTitle = TextStyle(
    color: KCustomColorTheme.kBlack,
    fontSize: kFontSizeM,
    fontWeight: FontWeight.w700,
  );
  static const TextStyle textStyleIcon = TextStyle(
    color: KCustomColorTheme.kBlack,
    fontSize: kFontSizeS,
    fontWeight: FontWeight.w400,
  );
}
