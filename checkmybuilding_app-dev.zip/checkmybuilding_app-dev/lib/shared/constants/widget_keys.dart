// ignore_for_file: constant_identifier_names

import 'package:flutter/foundation.dart';

/// Login page Widget Keys
const logIn_formPasswordInput_textFieldWidgetKey =
    ValueKey('logIn_formPassword_inputTextField');

const logIn_formUsernameInput_textFieldWidgetKey =
    ValueKey('logIn_formUsername_inputTextField');

const logIn_goToSignUp_buttonWidgetKey = ValueKey(
  'logIn_goToSignUp_button',
);

const logIn_submit_buttonWidgetKey = ValueKey(
  'logIn_Submit_button',
);

const logIn_formForgetPasswor_buttonWidgetKey = ValueKey(
  'logIn_formForgetPasswor_button',
);
const logIn_formTitleLogin_textWidgetKey = ValueKey(
  'logIn_formTitleLogin_text',
);
const logIn_divider_rowWidgetKey = ValueKey(
  'logIn_divider_row',
);
const logIn_formDontHaveAnnyAcc_buttonWidgetKey = ValueKey(
  'logIn_formDontHaveAnnyAcc_button',
);

/// SignUp page Widget Keys
const signUp_passwordInput_textFieldWidgetKey =
    ValueKey('signUp_password_inputTextField');

const signUp_usernameInput_textFieldWidgetKey = ValueKey(
  'signUp_username_inputTextField',
);

const signUp_submit_buttonWidgetKey = ValueKey(
  'signUp_submit_button',
);

const signUp_goToLogIn_buttonWidgetKey = ValueKey(
  'signUp_goToLogIn_button',
);
const signUp_toLoginPage_buttonWidgetKey = ValueKey(
  'signUp_toLoginPage_button',
);
const signUp_formAlreadyHaveAnAcc_buttonWidgetKey = ValueKey(
  'signUp_formAlreadyHaveAnAcc_button',
);
const signUp_formTitleSignUp_textWidgetKey = ValueKey(
  'signUp_formTitleSignUp_text',
);

/// Home page Widget Keys
const home_createNewAudit_buttonWidgetKey =
    ValueKey('home_createNewAudit_button');

const home_celendarOfAudits_buttonWidgetKey =
    ValueKey('home_celendarOfAudits_button');

const home_iconsColumn_buttonsWidgetKey = ValueKey(
  'home_iconsColumn_buttons',
);

const home_separatorWithText_widgetKey = ValueKey(
  'home_separatorWithText',
);
const home_itemAudit_widgetKey = ValueKey(
  'home_itemAudit',
);
const home_itemAuditLast_widgetKey = ValueKey(
  'home_itemAudit_last',
);

const homeState_showCustomDialog_useTemplate_buttonWidgetKey = ValueKey(
  'home_useTemplate_button',
);
const homeState_showCustomDialog_WidgetKey = ValueKey(
  'homeState_showCustomDialog',
);

const home_logOutButton_widgetKey = ValueKey(
  'home_logOutButton',
);
