// ignore: lines_longer_than_80_chars
// import 'dart:developer';
//
// import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
// import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
// import 'package:checkmybuilding/shared/repository/secure_storage_repository.dart';
// import 'package:checkmybuilding/shared/shared.dart';
// import 'package:dartz/dartz.dart';
// import 'package:dio/dio.dart';
// import 'package:injectable/injectable.dart';
// import 'package:pretty_dio_logger/pretty_dio_logger.dart';
//
// @Singleton()
// class DioClient {
//   factory DioClient() {
//     return _instance;
//   }
//
//   DioClient._privateConstructor();
//   static const String url = backendString;
//   static const String tokenKey = authTokenKey;
//
//   static BaseOptions opts = BaseOptions(
//     connectTimeout: const Duration(seconds: 30000),
//     receiveTimeout: const Duration(seconds: 30000),
//   );
//
//   static BaseOptions optsFakeDio = BaseOptions(
//     connectTimeout: const Duration(seconds: 30000),
//     receiveTimeout: const Duration(seconds: 30000),
//   );
//
//   static Dio createDio() {
//     final dio = Dio(opts);
//     addInterceptors(dio);
//     return dio;
//   }
//
//   static Dio fakeCreateDio() {
//     final dio = Dio(optsFakeDio);
//     addFakeDioInterceptors(dio);
//     return dio;
//   }
//
//   static Dio addInterceptors(Dio dio) {
//     final dio2 = dio
//       ..interceptors
//           .add(PrettyDioLogger(requestHeader: true, requestBody: true));
//     return dio2
//       ..interceptors.add(
//         InterceptorsWrapper(
//           onRequest: requestInterceptor,
//           onError: errorInterceptor,
//         ),
//       );
//   }
//
//   static Dio addFakeDioInterceptors(Dio dio) {
//     final dio2 = dio
//       ..interceptors
//           .add(PrettyDioLogger(requestHeader: true, requestBody: true));
//     return dio2
//       ..interceptors.add(
//         InterceptorsWrapper(
//           onError: errorInterceptor,
//         ),
//       );
//   }
//
//   static dynamic requestInterceptor(
//     RequestOptions options,
//     RequestInterceptorHandler requestInterceptorHandler,
//   ) async {
//     final token =
//         await getIt.get<SecureStorageRepository>().readOne(keyItem:
//         tokenKey);
//
//     if (token != '') {
//       options.headers.addAll({'Authorization': 'Bearer $token'});
//     }
//     return requestInterceptorHandler.next(options);
//   }
//
//   static dynamic errorInterceptor(
//     // ignore: deprecated_member_use
//     DioError e,
//     ErrorInterceptorHandler errorInterceptorHandler,
//   ) async {
//     if (e.response != null) {
//       if (e.response!.statusCode == 401) {
//         getIt<AuthenticationBloc>().add(AuthenticationLogoutRequested());
//       }
//     }
//
//     return errorInterceptorHandler.next(e);
//   }
//
//   static final dio = createDio();
//   static final dioFake = fakeCreateDio();
//
//   static final DioClient _instance = DioClient._privateConstructor();
//
//   Future<Either<AuthFailure, Response<dynamic>>> findAll({
//     required String endpoint,
//   }) async {
//     try {
//       // ignore: inference_failure_on_function_invocation
//       final response = await dio.request(
//         '/$endpoint',
//         options: Options(method: 'GET', responseType: ResponseType.json),
//       );
//
//       if (response.statusCode == 200) {
//         return Right(response);
//       } else if (response.statusCode == 401) {
//         return const Left(AuthFailure.unauthorized());
//       } else if (response.statusCode == 404) {
//         return const Left(AuthFailure.notfound());
//       } else if (response.statusCode == 409) {
//         return const Left(AuthFailure.duplicate());
//       } else if (response.statusCode == 429) {
//         return const Left(AuthFailure.tooManyRequests());
//       }
//       return const Left(AuthFailure.serverError());
//     } catch (e) {
//       return const Left(AuthFailure.serverError());
//     }
//   }
//
//   // ignore: strict_raw_type
//   Future<Either<AuthFailure, Response>> fakeAuthGet({
//     required String uuid,
//   }) async {
//     try {
//       // ignore: inference_failure_on_function_invocation
//       final response = await dioFake.request(
//         '/$uuid',
//         options: Options(method: 'GET', responseType: ResponseType.json),
//       );
//
//       if (response.statusCode == 200) {
//         // ignore: avoid_dynamic_calls
//         return response.data['error'] == true
//             ? const Left(AuthFailure.serverError())
//             : Right(response);
//       } else if (response.statusCode == 401) {
//         return const Left(AuthFailure.unauthorized());
//       } else if (response.statusCode == 404) {
//         return const Left(AuthFailure.notfound());
//       } else if (response.statusCode == 409) {
//         return const Left(AuthFailure.duplicate());
//       } else if (response.statusCode == 429) {
//         return const Left(AuthFailure.tooManyRequests());
//       }
//       return const Left(AuthFailure.serverError());
//       // ignore: deprecated_member_use
//     } on DioError catch (e) {
//       log(e.response.toString());
//       return const Left(AuthFailure.serverError());
//     }
//   }
//
//   // ignore: strict_raw_type
//   Future<Either<AuthFailure, Response>> post({
//     required String endpoint,
//     required dynamic data,
//   }) async {
//     try {
//       // ignore: inference_failure_on_function_invocation
//       final response = await dio.request(
//         '/$endpoint',
//         data: data,
//         options: Options(
//           method: 'POST',
//           responseType: ResponseType.json,
//         ),
//       );
//       if (response.statusCode == 200) {
//         return Right(response);
//       } else if (response.statusCode == 401) {
//         return const Left(AuthFailure.unauthorized());
//       } else if (response.statusCode == 404) {
//         return const Left(AuthFailure.notfound());
//       } else if (response.statusCode == 409) {
//         return const Left(AuthFailure.duplicate());
//       } else if (response.statusCode == 429) {
//         return const Left(AuthFailure.tooManyRequests());
//       }
//       return const Left(AuthFailure.serverError());
//     } catch (e) {
//       // log(e.toString());
//       return const Left(AuthFailure.serverError());
//     }
//   }
//   //
//   // Future<Either<AuthFailure, Response>> postNew(
//   //     {required String endpoint, dynamic? data}) async {
//   //   try {
//   //     var response = await baseAPI.post('$url/$endpoint', data: data);
//   //     if (response.statusCode == 200) {
//   //       return Right(response);
//   //     } else if (response.statusCode == 401) {
//   //       return const Left(AuthFailure.unauthorized());
//   //     } else if (response.statusCode == 404) {
//   //       return const Left(AuthFailure.notfound());
//   //     } else if (response.statusCode == 409) {
//   //       return const Left(AuthFailure.duplicate());
//   //     } else if (response.statusCode == 429) {
//   //       return const Left(AuthFailure.tooManyRequests());
//   //     }
//   //     // log(response.statusMessage.toString());
//   //     return const Left(AuthFailure.serverError());
//   //   } on DioError catch (e) {
//   //     // print(e.response.toString());
//   //     return const Left(AuthFailure.serverError());
//   //   }
//   // }
// }
