import 'package:freezed_annotation/freezed_annotation.dart';

part 'auth_failure_model.freezed.dart';

@freezed
class AuthFailure with _$AuthFailure {
  const factory AuthFailure.initial() = _Initial;
  const factory AuthFailure.serverError() = _ServerError;
  const factory AuthFailure.unauthorized() = _Unauthorized;
  const factory AuthFailure.notfound() = _NotFound;
  const factory AuthFailure.duplicate() = _Duplicate;
  const factory AuthFailure.tooManyRequests() = _TooManyRequests;
}
