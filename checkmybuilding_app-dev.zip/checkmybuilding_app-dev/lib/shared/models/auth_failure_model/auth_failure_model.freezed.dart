// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'auth_failure_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$AuthFailure {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AuthFailureCopyWith<$Res> {
  factory $AuthFailureCopyWith(
          AuthFailure value, $Res Function(AuthFailure) then) =
      _$AuthFailureCopyWithImpl<$Res, AuthFailure>;
}

/// @nodoc
class _$AuthFailureCopyWithImpl<$Res, $Val extends AuthFailure>
    implements $AuthFailureCopyWith<$Res> {
  _$AuthFailureCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$InitialImplCopyWith<$Res> {
  factory _$$InitialImplCopyWith(
          _$InitialImpl value, $Res Function(_$InitialImpl) then) =
      __$$InitialImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InitialImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$InitialImpl>
    implements _$$InitialImplCopyWith<$Res> {
  __$$InitialImplCopyWithImpl(
      _$InitialImpl _value, $Res Function(_$InitialImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$InitialImpl implements _Initial {
  const _$InitialImpl();

  @override
  String toString() {
    return 'AuthFailure.initial()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$InitialImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return initial();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return initial?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return initial(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return initial?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (initial != null) {
      return initial(this);
    }
    return orElse();
  }
}

abstract class _Initial implements AuthFailure {
  const factory _Initial() = _$InitialImpl;
}

/// @nodoc
abstract class _$$ServerErrorImplCopyWith<$Res> {
  factory _$$ServerErrorImplCopyWith(
          _$ServerErrorImpl value, $Res Function(_$ServerErrorImpl) then) =
      __$$ServerErrorImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$ServerErrorImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$ServerErrorImpl>
    implements _$$ServerErrorImplCopyWith<$Res> {
  __$$ServerErrorImplCopyWithImpl(
      _$ServerErrorImpl _value, $Res Function(_$ServerErrorImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$ServerErrorImpl implements _ServerError {
  const _$ServerErrorImpl();

  @override
  String toString() {
    return 'AuthFailure.serverError()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$ServerErrorImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return serverError();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return serverError?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (serverError != null) {
      return serverError();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return serverError(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return serverError?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (serverError != null) {
      return serverError(this);
    }
    return orElse();
  }
}

abstract class _ServerError implements AuthFailure {
  const factory _ServerError() = _$ServerErrorImpl;
}

/// @nodoc
abstract class _$$UnauthorizedImplCopyWith<$Res> {
  factory _$$UnauthorizedImplCopyWith(
          _$UnauthorizedImpl value, $Res Function(_$UnauthorizedImpl) then) =
      __$$UnauthorizedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$UnauthorizedImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$UnauthorizedImpl>
    implements _$$UnauthorizedImplCopyWith<$Res> {
  __$$UnauthorizedImplCopyWithImpl(
      _$UnauthorizedImpl _value, $Res Function(_$UnauthorizedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$UnauthorizedImpl implements _Unauthorized {
  const _$UnauthorizedImpl();

  @override
  String toString() {
    return 'AuthFailure.unauthorized()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$UnauthorizedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return unauthorized();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return unauthorized?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (unauthorized != null) {
      return unauthorized();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return unauthorized(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return unauthorized?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (unauthorized != null) {
      return unauthorized(this);
    }
    return orElse();
  }
}

abstract class _Unauthorized implements AuthFailure {
  const factory _Unauthorized() = _$UnauthorizedImpl;
}

/// @nodoc
abstract class _$$NotFoundImplCopyWith<$Res> {
  factory _$$NotFoundImplCopyWith(
          _$NotFoundImpl value, $Res Function(_$NotFoundImpl) then) =
      __$$NotFoundImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NotFoundImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$NotFoundImpl>
    implements _$$NotFoundImplCopyWith<$Res> {
  __$$NotFoundImplCopyWithImpl(
      _$NotFoundImpl _value, $Res Function(_$NotFoundImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$NotFoundImpl implements _NotFound {
  const _$NotFoundImpl();

  @override
  String toString() {
    return 'AuthFailure.notfound()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$NotFoundImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return notfound();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return notfound?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (notfound != null) {
      return notfound();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return notfound(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return notfound?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (notfound != null) {
      return notfound(this);
    }
    return orElse();
  }
}

abstract class _NotFound implements AuthFailure {
  const factory _NotFound() = _$NotFoundImpl;
}

/// @nodoc
abstract class _$$DuplicateImplCopyWith<$Res> {
  factory _$$DuplicateImplCopyWith(
          _$DuplicateImpl value, $Res Function(_$DuplicateImpl) then) =
      __$$DuplicateImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$DuplicateImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$DuplicateImpl>
    implements _$$DuplicateImplCopyWith<$Res> {
  __$$DuplicateImplCopyWithImpl(
      _$DuplicateImpl _value, $Res Function(_$DuplicateImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$DuplicateImpl implements _Duplicate {
  const _$DuplicateImpl();

  @override
  String toString() {
    return 'AuthFailure.duplicate()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$DuplicateImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return duplicate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return duplicate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (duplicate != null) {
      return duplicate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return duplicate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return duplicate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (duplicate != null) {
      return duplicate(this);
    }
    return orElse();
  }
}

abstract class _Duplicate implements AuthFailure {
  const factory _Duplicate() = _$DuplicateImpl;
}

/// @nodoc
abstract class _$$TooManyRequestsImplCopyWith<$Res> {
  factory _$$TooManyRequestsImplCopyWith(_$TooManyRequestsImpl value,
          $Res Function(_$TooManyRequestsImpl) then) =
      __$$TooManyRequestsImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$TooManyRequestsImplCopyWithImpl<$Res>
    extends _$AuthFailureCopyWithImpl<$Res, _$TooManyRequestsImpl>
    implements _$$TooManyRequestsImplCopyWith<$Res> {
  __$$TooManyRequestsImplCopyWithImpl(
      _$TooManyRequestsImpl _value, $Res Function(_$TooManyRequestsImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$TooManyRequestsImpl implements _TooManyRequests {
  const _$TooManyRequestsImpl();

  @override
  String toString() {
    return 'AuthFailure.tooManyRequests()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$TooManyRequestsImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() initial,
    required TResult Function() serverError,
    required TResult Function() unauthorized,
    required TResult Function() notfound,
    required TResult Function() duplicate,
    required TResult Function() tooManyRequests,
  }) {
    return tooManyRequests();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function()? initial,
    TResult? Function()? serverError,
    TResult? Function()? unauthorized,
    TResult? Function()? notfound,
    TResult? Function()? duplicate,
    TResult? Function()? tooManyRequests,
  }) {
    return tooManyRequests?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? initial,
    TResult Function()? serverError,
    TResult Function()? unauthorized,
    TResult Function()? notfound,
    TResult Function()? duplicate,
    TResult Function()? tooManyRequests,
    required TResult orElse(),
  }) {
    if (tooManyRequests != null) {
      return tooManyRequests();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_Initial value) initial,
    required TResult Function(_ServerError value) serverError,
    required TResult Function(_Unauthorized value) unauthorized,
    required TResult Function(_NotFound value) notfound,
    required TResult Function(_Duplicate value) duplicate,
    required TResult Function(_TooManyRequests value) tooManyRequests,
  }) {
    return tooManyRequests(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_Initial value)? initial,
    TResult? Function(_ServerError value)? serverError,
    TResult? Function(_Unauthorized value)? unauthorized,
    TResult? Function(_NotFound value)? notfound,
    TResult? Function(_Duplicate value)? duplicate,
    TResult? Function(_TooManyRequests value)? tooManyRequests,
  }) {
    return tooManyRequests?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_Initial value)? initial,
    TResult Function(_ServerError value)? serverError,
    TResult Function(_Unauthorized value)? unauthorized,
    TResult Function(_NotFound value)? notfound,
    TResult Function(_Duplicate value)? duplicate,
    TResult Function(_TooManyRequests value)? tooManyRequests,
    required TResult orElse(),
  }) {
    if (tooManyRequests != null) {
      return tooManyRequests(this);
    }
    return orElse();
  }
}

abstract class _TooManyRequests implements AuthFailure {
  const factory _TooManyRequests() = _$TooManyRequestsImpl;
}
