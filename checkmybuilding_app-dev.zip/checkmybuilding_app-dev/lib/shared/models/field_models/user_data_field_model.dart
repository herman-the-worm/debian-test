import 'package:formz/formz.dart';

enum UsernameDataFieldModelValidationError { empty }

class UsernameDataFieldModel
    extends FormzInput<String?, UsernameDataFieldModelValidationError> {
  const UsernameDataFieldModel.pure() : super.pure(null);

  const UsernameDataFieldModel.dirty([super.value = '']) : super.dirty();

  @override
  UsernameDataFieldModelValidationError? validator(String? value) {
    if (value == null) {
      return UsernameDataFieldModelValidationError.empty;
    }
    if (value.isEmpty) {
      return UsernameDataFieldModelValidationError.empty;
    }
    return null;
  }
}
