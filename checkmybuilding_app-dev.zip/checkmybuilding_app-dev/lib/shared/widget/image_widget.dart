import 'package:flutter/material.dart';

class ImageWidget extends StatelessWidget {
  const ImageWidget({
    required this.localImage,
    required this.imageString,
    super.key,
  });

  final String imageString;
  final bool localImage;

  @override
  Widget build(BuildContext context) {
    return localImage
        ? Image.asset(
            imageString,
          )
        : Image.network(imageString);
  }
}
