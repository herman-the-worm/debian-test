import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class DividerRowWidget extends StatelessWidget {
  const DividerRowWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      key: logIn_divider_rowWidgetKey,
      mainAxisAlignment: MainAxisAlignment.center,
      children: const [
        if (kIsWeb)
          Spacer(
            flex: 2,
          ),
        Expanded(
          child: Divider(
            color: Colors.black,
            thickness: 1,
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 16,
          ),
          child: Text('OR'),
        ),
        Expanded(
          child: Divider(
            color: Colors.black,
            thickness: 1,
          ),
        ),
        if (kIsWeb)
          Spacer(
            flex: 2,
          ),
      ],
    );
  }
}
