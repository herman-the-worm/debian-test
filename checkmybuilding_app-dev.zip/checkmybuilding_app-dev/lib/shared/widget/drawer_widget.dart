import 'package:checkmybuilding/shared/constants/route_constant.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DrawerWidget extends StatelessWidget {
  const DrawerWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home page'),
            onTap: () => context.go(KRouteStatic.home.path),
          ),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('My Profile'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.book),
            title: const Text('My Templates'),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.support),
            title: const Text('Support'),
            onTap: () {},
          ),
          const Padding(
            padding: EdgeInsets.only(
              left: 25,
              right: 25,
              top: 40,
            ),
            child: Divider(),
          ),
          ListTile(
            title: const Center(child: Text('Privacy Policy')),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
