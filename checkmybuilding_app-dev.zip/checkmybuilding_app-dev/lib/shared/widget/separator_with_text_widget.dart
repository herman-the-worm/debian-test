import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:flutter/material.dart';

class SeparatorWithTextWidget extends StatelessWidget {
  const SeparatorWithTextWidget({
    required this.separatorTitle,
    required this.width,
    required this.height,
    super.key,
  });
  final double width;
  final double height;
  final String separatorTitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      key: home_separatorWithText_widgetKey,
      width: width,
      height: height,
      color: KCustomColorTheme.kGreyMain,
      child: Center(
        child: Text(separatorTitle),
      ),
    );
  }
}
