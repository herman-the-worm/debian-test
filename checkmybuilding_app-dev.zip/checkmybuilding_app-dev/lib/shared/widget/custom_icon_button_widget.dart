import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/text_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/widgets_constant.dart';
import 'package:flutter/material.dart';

class CustomIconButtonWidget extends StatelessWidget {
  const CustomIconButtonWidget({
    required this.buttonNaming,
    required this.buttonIcon,
    required this.onTap,
    this.style,
    this.height,
    this.width,
    super.key,
  });
  final String buttonNaming;
  final IconData buttonIcon;
  final VoidCallback onTap;
  final double? height;
  final double? width;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Ink(
        height: height ?? 50,
        width: width ?? 50,
        color: KCustomColorTheme.kDarkGrey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(buttonIcon),
            SizedBoxStatic.kHeightSizedBoxS,
            Text(
              buttonNaming,
              textAlign: TextAlign.center,
              softWrap: true,
              style: style ?? KCustomTextTheme.textStyleIcon,
            ),
          ],
        ),
      ),
    );
  }
}
