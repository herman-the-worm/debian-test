import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class SquareButtonWidget extends StatelessWidget {
  const SquareButtonWidget({
    required this.buttonNaming,
    required this.buttonIcon,
    required this.onTap,
    this.style,
    this.height,
    this.width,
    super.key,
  });
  final String buttonNaming;
  final IconData buttonIcon;
  final VoidCallback onTap;
  final double? height;
  final double? width;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Ink(
        height: height ?? 100,
        width: width ?? 100,
        color: KCustomColorTheme.kDarkGrey,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(buttonIcon),
            SizedBoxStatic.kHeightSizedBoxXS,
            Text(
              buttonNaming,
              textAlign: TextAlign.center,
              softWrap: true,
              style: style ?? KCustomTextTheme.textSquareButtonStyle,
            ),
          ],
        ),
      ),
    );
  }
}
