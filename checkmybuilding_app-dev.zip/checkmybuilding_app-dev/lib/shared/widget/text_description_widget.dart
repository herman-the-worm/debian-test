import 'package:flutter/material.dart';

class TextDescriptionWidget extends StatelessWidget {
  const TextDescriptionWidget({
    required this.title,
    this.overflow,
    this.maxLines,
    super.key,
  });
  final String title;
  final TextOverflow? overflow;
  final int? maxLines;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      overflow: overflow ?? TextOverflow.ellipsis,
      maxLines: maxLines ?? 1,
    );
  }
}
