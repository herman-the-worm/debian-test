import 'package:flutter/material.dart';

class TitleTextWidget extends StatelessWidget {
  const TitleTextWidget({
    required this.title,
    required this.style,
    super.key,
  });
  final String title;
  final TextStyle style;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: style,
      // key: logIn_formTitleLogin_textWidgetKey,
    );
  }
}
