import 'package:checkmybuilding/shared/models/models.dart';
import 'package:dartz/dartz.dart';

abstract class IAppAuthenticationRepository {
  Stream<User> get user;
  User get currentUser;
  Future<void> logInWithGoogle();
  Future<Either<AuthFailure, bool>> logInWithEmailAndPassword({
    required String email,
    required String password,
  });
  Future<Either<AuthFailure, bool>> signUp({
    required String email,
    required String password,
  });
  Future<bool> isLoggedIn();
  Future<void> logOut();
  Future<String?> getUser();
}
