import 'package:injectable/injectable.dart';

@Injectable()
class BaseRepository {
  BaseRepository(
      // this.dioClient,
      );
  // final DioClient dioClient;
}
