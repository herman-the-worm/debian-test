import 'dart:async';

import 'package:checkmybuilding/shared/data_providers/cache_provider.dart';
import 'package:checkmybuilding/shared/repository/base_repository.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:checkmybuilding/shared/repository/i_storage_repository.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:flutter/foundation.dart'
    show debugPrint, kIsWeb, visibleForTesting;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:injectable/injectable.dart';

@Singleton(as: IAppAuthenticationRepository)
class AppAuthenticationRepository extends BaseRepository
    implements IAppAuthenticationRepository {
  AppAuthenticationRepository(
    // super.dioClient,
    this._secureStorageRepository,
    this._firebaseAuth,
    this._googleSignIn,
    this._cache,
  ) {
    _updateAuthStatusBasedOnCache();
  }
  final IStorage _secureStorageRepository;
  final firebase_auth.FirebaseAuth _firebaseAuth;
  final GoogleSignIn _googleSignIn;
  final CacheClient _cache;

  /// Whether or not the current environment is web
  /// Should only be overridden for testing purposes. Otherwise,
  /// defaults to [kIsWeb]
  @visibleForTesting
  bool isWeb = kIsWeb;

  /// User cache key.
  /// Should only be used for testing purposes.
  @visibleForTesting
  static const userCacheKey = '__user_cache_key__';

  // /// Stream of [User] which will emit the current user when
  // /// the authentication state changes.
  // ///
  // /// Emits [User.empty] if the user is not authenticated.
  @override
  Stream<User> get user => _firebaseAuth.authStateChanges().map(
        (firebaseUser) {
          debugPrint('================================================');
          if (firebaseUser != null) {
            debugPrint('Firebase Auth State Changed: User is authenticated');
            debugPrint('Firebase User Details: $firebaseUser');
            return firebaseUser.toUser;
          } else {
            debugPrint('Firebase Auth State Changed: '
                'User is unauthenticated (User.empty)');
            return User.empty;
          }
        },
      );

  //
  // /// Returns the current cached user.
  // /// Defaults to [User.empty] if there is no cached user.
  @override
  User get currentUser => _cache.read<User>(key: userCacheKey) ?? User.empty;

  static const String tokenKey = authTokenKey;
  static const String url = backendString;

  /// Starts the Sign In with Google Flow.
  ///
  /// Throws a [LogInWithGoogleFailure] if an exception occurs.
  @override
  Future<void> logInWithGoogle() async {
    try {
      await _firebaseAuth
          .signInWithCredential(await _getGoogleAuthCredential());
    } on firebase_auth.FirebaseAuthException catch (e) {
      throw LogInWithGoogleFailure.fromCode(e.code);
    } catch (_) {
      throw const LogInWithGoogleFailure();
    } finally {
      _updateAuthStatusBasedOnCache();
    }
  }

  Future<firebase_auth.AuthCredential> _getGoogleAuthCredential() async {
    if (isWeb) {
      return _getGoogleAuthCredentialWeb();
    } else {
      return _getGoogleAuthCredentialMobile();
    }
  }

  Future<firebase_auth.AuthCredential> _getGoogleAuthCredentialWeb() async {
    final userCredential =
        await _firebaseAuth.signInWithPopup(firebase_auth.GoogleAuthProvider());
    return userCredential.credential!;
  }

  Future<firebase_auth.AuthCredential> _getGoogleAuthCredentialMobile() async {
    final googleUser = await _googleSignIn.signIn();
    final googleAuth = await googleUser!.authentication;
    return firebase_auth.GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
  }

  /// Signs in with the provided [email] and [password].
  ///
  /// Throws a [LogInWithEmailAndPasswordFailure] if an exception occurs.
  @override
  Future<Either<AuthFailure, bool>> logInWithEmailAndPassword({
    required String email,
    required String password,
  }) async =>
      _handleAuthOperation(
        () => _firebaseAuth.signInWithEmailAndPassword(
          email: email,
          password: password,
        ),
      );

  /// Creates a new user with the provided [email] and [password].
  ///
  /// Throws a [SignUpWithEmailAndPasswordFailure] if an exception occurs.
  @override
  Future<Either<AuthFailure, bool>> signUp({
    required String email,
    required String password,
  }) async {
    return _handleAuthOperation(
      () => _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      ),
    );
  }

  @override
  Future<bool> isLoggedIn() async => currentUser != User.empty;

  /// Signs out the current user which will emit
  /// [User.empty] from the [user] Stream.
  ///
  /// Throws a [LogOutFailure] if an exception occurs.
  @override
  Future<void> logOut() async {
    try {
      _cache.clear();
      await Future.wait([
        _firebaseAuth.signOut(),
        _googleSignIn.signOut(),
        _secureStorageRepository.deleteAll(),
      ]);
    } catch (e) {
      debugPrint('Logout error: $e');
      throw LogOutFailure();
    } finally {
      _updateAuthStatusBasedOnCache();
    }
  }

  @override
  Future<String?> getUser() async {
    final token = await _secureStorageRepository.readOne(
      keyItem: usernameToken,
    );
    return token;
  }

  Future<Either<AuthFailure, bool>> _handleAuthOperation(
    Future<void> Function() operation,
  ) async {
    try {
      await operation();
      return const Right(true);
    } on firebase_auth.FirebaseAuthException catch (e) {
      debugPrint('Firebase Auth Error: ${e.message}');
      return const Left(AuthFailure.serverError());
    } catch (e) {
      debugPrint('General Auth Error: $e');
      return const Left(AuthFailure.serverError());
    } finally {
      _updateAuthStatusBasedOnCache();
    }
  }

  void _updateAuthStatusBasedOnCache() {
    debugPrint('Updating auth status based on cache');
    final user = currentUser != User.empty;
    debugPrint('Current user inside '
        '_updateAuthStatusBasedOnCache : $currentUser');
    debugPrint('user is $user');
  }
}

extension on firebase_auth.User {
  User get toUser => User(
        id: uid,
        email: email,
        name: displayName,
        photo: photoURL,
      );
}
