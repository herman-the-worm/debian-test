abstract class IFirebaseAuth<TUser, UserCredential> {
  Future<UserCredential> signInWithEmailAndPassword({
    required String email,
    required String password,
  });
  Future<UserCredential> createUserWithEmailAndPassword({
    required String email,
    required String password,
  });
  Future<void> signOut();
  TUser? getCurrentUser();
  Stream<TUser?> authStateChanges();
// Add other methods as needed
}
