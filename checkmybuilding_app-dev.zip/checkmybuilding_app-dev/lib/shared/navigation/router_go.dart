import 'package:checkmybuilding/components/error/view/error_view.dart';
import 'package:checkmybuilding/components/home/view/home_view.dart';
import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/components/sign_up/view/sign_up_view.dart';
import 'package:checkmybuilding/components/template/view/template_view.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/bloc/authentication/listenable.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/navigation/navigation.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:go_router/go_router.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter router = GoRouter(
  routerNeglect: true,
  navigatorKey: _rootNavigatorKey,
  debugLogDiagnostics: true,
  errorBuilder: (context, state) => const ErrorScreen(),
  refreshListenable:
      GoRouterRefreshStream(GetIt.instance<AuthenticationBloc>().stream),
  initialLocation: KRouteStatic.home.path,
  redirect: (BuildContext context, GoRouterState state) async {
    if (context.read<AuthenticationBloc>().state.status ==
        AuthenticationStatus.authenticated) {
      return state.uri.toString().contains(KRouteStatic.login.path) ||
              state.uri.toString().contains(KRouteStatic.signUp.path)
          ? KRouteStatic.home.path
          : null;
    }
    return null;
  },
  routes: [
    GoRoute(
      path: KRouteStatic.login.path,
      pageBuilder: (context, state) => NoTransitionPage(
        key: state.pageKey,
        child: const LoginScreen(),
      ),
    ),
    GoRoute(
      path: KRouteStatic.home.path,
      redirect: redirect,
      pageBuilder: (context, state) => NoTransitionPage(
        key: state.pageKey,
        child: const HomeScreen(),
      ),
    ),
    GoRoute(
      path: KRouteStatic.signUp.path,
      pageBuilder: (context, state) => NoTransitionPage(
        key: state.pageKey,
        child: const SignUpScreen(),
      ),
    ),
    GoRoute(
      path: KRouteStatic.template.path,
      pageBuilder: (context, state) => NoTransitionPage(
        key: state.pageKey,
        child: const TemplateScreen(),
      ),
    ),
  ],
);
