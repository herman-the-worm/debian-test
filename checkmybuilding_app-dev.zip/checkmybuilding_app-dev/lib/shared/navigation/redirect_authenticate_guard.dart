import 'dart:async';

import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

FutureOr<String?> Function(BuildContext, GoRouterState)? redirect =
    (BuildContext context, GoRouterState state) {
  if (context.read<AuthenticationBloc>().state.status ==
          AuthenticationStatus.unknown ||
      context.read<AuthenticationBloc>().state.status ==
          AuthenticationStatus.unauthenticated) {
    return KRouteStatic.login.path;
  }
  return null;
};
