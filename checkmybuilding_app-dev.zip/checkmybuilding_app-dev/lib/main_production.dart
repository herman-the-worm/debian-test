import 'package:checkmybuilding/app.dart';
import 'package:checkmybuilding/bootstrap.dart';

void main() {
  bootstrap(() => const App());
}
