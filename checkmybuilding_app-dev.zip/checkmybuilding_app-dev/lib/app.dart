import 'package:checkmybuilding/l10n/l10n.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/navigation/navigation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => getIt.get<AuthenticationBloc>()
            ..add(
              AuthenticationInitialized(),
            ),
        ),
      ],
      child: const AppWidget(),
    );
  }
}

class AppWidget extends StatelessWidget {
  const AppWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      builder: (context, state) {
        return MaterialApp.router(
          theme: themeData,
          localizationsDelegates: AppLocalizations.localizationsDelegates,
          supportedLocales: AppLocalizations.supportedLocales,
          routerConfig: router,
        );
      },
    );
  }
}
