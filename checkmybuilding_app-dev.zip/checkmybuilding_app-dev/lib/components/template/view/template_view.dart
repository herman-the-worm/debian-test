import 'package:checkmybuilding/components/template/widget/body/template_body_widget.dart';
import 'package:checkmybuilding/components/template/widget/button/template_menu_button_widget.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/widget/drawer_widget.dart';
import 'package:flutter/material.dart';

class TemplateScreen extends StatelessWidget {
  const TemplateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      endDrawer: const DrawerWidget(),
      appBar: AppBar(
        backgroundColor: KCustomColorTheme.kLightGrey,
        actions: const [
          TemplateMenuButtonWidget(),
        ],
        // leading: const BackButton(color: kBlack),
      ),
      body: const TemplateBodyWidget(),
    );
  }
}
