import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:flutter/material.dart';

class TemplateMenuButtonWidget extends StatelessWidget {
  const TemplateMenuButtonWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () => Scaffold.of(context).openEndDrawer(),
      icon: const Icon(
        Icons.menu,
        color: KCustomColorTheme.kBlack,
      ),
    );
  }
}
