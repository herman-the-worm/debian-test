import 'package:checkmybuilding/shared/constants/text_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/widgets_constant.dart';
import 'package:checkmybuilding/shared/widget/square_button_widget.dart';
import 'package:checkmybuilding/shared/widget/title_text_widget.dart';
import 'package:flutter/material.dart';

class TemplateBodyWidget extends StatelessWidget {
  const TemplateBodyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        top: KPaddingSizeStatic.kPaddingSizeM,
        left: KPaddingSizeStatic.kPaddingSizeSM,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const TitleTextWidget(
            title: 'Template',
            style: KCustomTextTheme.textStyleBlackTitle,
          ),
          SizedBoxStatic.kHeightSizedBoxM,
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SquareButtonWidget(
                buttonNaming: 'Home Energy Audit template',
                buttonIcon: Icons.file_copy,
                onTap: () {},
              ),
              SizedBoxStatic.kWidthSizedBoxM,
              SquareButtonWidget(
                buttonNaming: 'Home Inspection template',
                buttonIcon: Icons.file_copy,
                onTap: () {},
              ),
            ],
          ),
          SizedBoxStatic.kHeightSizedBoxM,
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SquareButtonWidget(
                buttonNaming: 'Roof Inspection template',
                buttonIcon: Icons.file_copy,
                onTap: () {},
              ),
              SizedBoxStatic.kWidthSizedBoxM,
              SquareButtonWidget(
                buttonNaming: 'Create your own tempalte',
                buttonIcon: Icons.file_download,
                onTap: () {},
              ),
            ],
          ),
          SizedBoxStatic.kHeightSizedBoxM,
          const TitleTextWidget(
            title: 'Saved template',
            style: KCustomTextTheme.textStyleBlackTitle,
          ),
          SizedBoxStatic.kHeightSizedBoxM,
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SquareButtonWidget(
                buttonNaming: 'My Home Energy Audit template',
                buttonIcon: Icons.file_copy,
                onTap: () {},
              ),
              SizedBoxStatic.kWidthSizedBoxM,
              SquareButtonWidget(
                buttonNaming: 'My Home Energy Audit template',
                buttonIcon: Icons.file_copy,
                onTap: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
