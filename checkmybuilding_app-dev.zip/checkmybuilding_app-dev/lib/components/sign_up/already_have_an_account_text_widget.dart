import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class AlreadyHaveAnAccTextWidget extends StatelessWidget {
  const AlreadyHaveAnAccTextWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const Text(
      'Already have an account?',
      style: KCustomTextTheme.textStyleBlackMain,
      key: signUp_formAlreadyHaveAnAcc_buttonWidgetKey,
    );
  }
}
