import 'package:checkmybuilding/components/sign_up/widget/widget.dart';
import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:flutter/material.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SignUpBlocProviderWidget(
      childWidget: Scaffold(
        appBar: AppBar(
          backgroundColor: KCustomColorTheme.kLightGrey,
        ),
        body: const SignUpBodyWidget(),
      ),
    );
  }
}
