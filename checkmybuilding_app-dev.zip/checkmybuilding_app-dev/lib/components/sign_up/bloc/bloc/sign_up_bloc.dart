import 'package:bloc/bloc.dart';
import 'package:checkmybuilding/shared/models/field_models/password_field_model.dart';
import 'package:checkmybuilding/shared/models/field_models/user_data_field_model.dart';
import 'package:checkmybuilding/shared/repository/i_app_authentication_repository.dart';
import 'package:flutter/foundation.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';

part 'sign_up_bloc.freezed.dart';
part 'sign_up_event.dart';
part 'sign_up_state.dart';

@injectable
class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  SignUpBloc(this.iAppAuthenticationRepository)
      : super(
          const SignUpState(
            status: FormzSubmissionStatus.initial,
            usernameDataFieldModel: UsernameDataFieldModel.pure(),
            passwordFieldModel: PasswordFieldModel.pure(),
            error: SignUpError.initial,
            isValid: false,
          ),
        ) {
    on<_SignUpFormUsernameChanged>(_onSignUpFormUsernameChanged);
    on<_SignUpFormPasswordChanged>(_onSignUpFormPasswordChanged);
    on<_SignUpSubmitted>(_onSignUpSubmitted);
    // on<_LoginReset>(_onLoginReset);
  }
  final IAppAuthenticationRepository iAppAuthenticationRepository;

  Future<void> _onSignUpFormUsernameChanged(
    _SignUpFormUsernameChanged event,
    Emitter<SignUpState> emit,
  ) async {
    final usernameDataFieldModel = UsernameDataFieldModel.dirty(event.username);
    emit(
      state.copyWith(
        usernameDataFieldModel: usernameDataFieldModel,
        isValid: Formz.validate([
          usernameDataFieldModel,
          state.passwordFieldModel,
        ]),
      ),
    );
  }

  Future<void> _onSignUpFormPasswordChanged(
    _SignUpFormPasswordChanged event,
    Emitter<SignUpState> emit,
  ) async {
    final passwordFieldModel = PasswordFieldModel.dirty(event.password);
    emit(
      state.copyWith(
        passwordFieldModel: passwordFieldModel,
        isValid: Formz.validate([
          passwordFieldModel,
          state.usernameDataFieldModel,
        ]),
      ),
    );
  }

  Future<void> _onSignUpSubmitted(
    _SignUpSubmitted event,
    Emitter<SignUpState> emit,
  ) async {
    if (state.isValid) {
      emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
      try {
        final result = await iAppAuthenticationRepository.signUp(
          email: state.usernameDataFieldModel.value!,
          password: state.passwordFieldModel.value,
        );
        emit(
          result.fold(
            (l) => state.copyWith(status: FormzSubmissionStatus.failure),
            (r) => state.copyWith(status: FormzSubmissionStatus.success),
          ),
        );
      } on Exception catch (e) {
        debugPrint(e.toString());
        emit(state.copyWith(status: FormzSubmissionStatus.failure));
      }
    }
  }
}
