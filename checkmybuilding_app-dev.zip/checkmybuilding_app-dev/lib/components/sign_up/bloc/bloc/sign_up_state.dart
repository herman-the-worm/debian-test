part of 'sign_up_bloc.dart';

enum SignUpError { duplicate, error, initial, toomany }

@freezed
class SignUpState with _$SignUpState {
  const factory SignUpState({
    required FormzSubmissionStatus status,
    required UsernameDataFieldModel usernameDataFieldModel,
    required PasswordFieldModel passwordFieldModel,
    required SignUpError error,
    required bool isValid,
  }) = _SignUpState;
}
