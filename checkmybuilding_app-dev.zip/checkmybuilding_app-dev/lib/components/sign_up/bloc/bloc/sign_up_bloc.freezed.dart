// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sign_up_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$SignUpEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) signUpFormUsernameChanged,
    required TResult Function(String password) signUpFormPasswordChanged,
    required TResult Function() signUpSubmitted,
    required TResult Function() reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? signUpFormUsernameChanged,
    TResult? Function(String password)? signUpFormPasswordChanged,
    TResult? Function()? signUpSubmitted,
    TResult? Function()? reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? signUpFormUsernameChanged,
    TResult Function(String password)? signUpFormPasswordChanged,
    TResult Function()? signUpSubmitted,
    TResult Function()? reset,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SignUpFormUsernameChanged value)
        signUpFormUsernameChanged,
    required TResult Function(_SignUpFormPasswordChanged value)
        signUpFormPasswordChanged,
    required TResult Function(_SignUpSubmitted value) signUpSubmitted,
    required TResult Function(_SignUpReset value) reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult? Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult? Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult? Function(_SignUpReset value)? reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult Function(_SignUpReset value)? reset,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SignUpEventCopyWith<$Res> {
  factory $SignUpEventCopyWith(
          SignUpEvent value, $Res Function(SignUpEvent) then) =
      _$SignUpEventCopyWithImpl<$Res, SignUpEvent>;
}

/// @nodoc
class _$SignUpEventCopyWithImpl<$Res, $Val extends SignUpEvent>
    implements $SignUpEventCopyWith<$Res> {
  _$SignUpEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$SignUpFormUsernameChangedImplCopyWith<$Res> {
  factory _$$SignUpFormUsernameChangedImplCopyWith(
          _$SignUpFormUsernameChangedImpl value,
          $Res Function(_$SignUpFormUsernameChangedImpl) then) =
      __$$SignUpFormUsernameChangedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String username});
}

/// @nodoc
class __$$SignUpFormUsernameChangedImplCopyWithImpl<$Res>
    extends _$SignUpEventCopyWithImpl<$Res, _$SignUpFormUsernameChangedImpl>
    implements _$$SignUpFormUsernameChangedImplCopyWith<$Res> {
  __$$SignUpFormUsernameChangedImplCopyWithImpl(
      _$SignUpFormUsernameChangedImpl _value,
      $Res Function(_$SignUpFormUsernameChangedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? username = null,
  }) {
    return _then(_$SignUpFormUsernameChangedImpl(
      null == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SignUpFormUsernameChangedImpl
    with DiagnosticableTreeMixin
    implements _SignUpFormUsernameChanged {
  const _$SignUpFormUsernameChangedImpl(this.username);

  @override
  final String username;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SignUpEvent.signUpFormUsernameChanged(username: $username)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'SignUpEvent.signUpFormUsernameChanged'))
      ..add(DiagnosticsProperty('username', username));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignUpFormUsernameChangedImpl &&
            (identical(other.username, username) ||
                other.username == username));
  }

  @override
  int get hashCode => Object.hash(runtimeType, username);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignUpFormUsernameChangedImplCopyWith<_$SignUpFormUsernameChangedImpl>
      get copyWith => __$$SignUpFormUsernameChangedImplCopyWithImpl<
          _$SignUpFormUsernameChangedImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) signUpFormUsernameChanged,
    required TResult Function(String password) signUpFormPasswordChanged,
    required TResult Function() signUpSubmitted,
    required TResult Function() reset,
  }) {
    return signUpFormUsernameChanged(username);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? signUpFormUsernameChanged,
    TResult? Function(String password)? signUpFormPasswordChanged,
    TResult? Function()? signUpSubmitted,
    TResult? Function()? reset,
  }) {
    return signUpFormUsernameChanged?.call(username);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? signUpFormUsernameChanged,
    TResult Function(String password)? signUpFormPasswordChanged,
    TResult Function()? signUpSubmitted,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (signUpFormUsernameChanged != null) {
      return signUpFormUsernameChanged(username);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SignUpFormUsernameChanged value)
        signUpFormUsernameChanged,
    required TResult Function(_SignUpFormPasswordChanged value)
        signUpFormPasswordChanged,
    required TResult Function(_SignUpSubmitted value) signUpSubmitted,
    required TResult Function(_SignUpReset value) reset,
  }) {
    return signUpFormUsernameChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult? Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult? Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult? Function(_SignUpReset value)? reset,
  }) {
    return signUpFormUsernameChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult Function(_SignUpReset value)? reset,
    required TResult orElse(),
  }) {
    if (signUpFormUsernameChanged != null) {
      return signUpFormUsernameChanged(this);
    }
    return orElse();
  }
}

abstract class _SignUpFormUsernameChanged implements SignUpEvent {
  const factory _SignUpFormUsernameChanged(final String username) =
      _$SignUpFormUsernameChangedImpl;

  String get username;
  @JsonKey(ignore: true)
  _$$SignUpFormUsernameChangedImplCopyWith<_$SignUpFormUsernameChangedImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SignUpFormPasswordChangedImplCopyWith<$Res> {
  factory _$$SignUpFormPasswordChangedImplCopyWith(
          _$SignUpFormPasswordChangedImpl value,
          $Res Function(_$SignUpFormPasswordChangedImpl) then) =
      __$$SignUpFormPasswordChangedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String password});
}

/// @nodoc
class __$$SignUpFormPasswordChangedImplCopyWithImpl<$Res>
    extends _$SignUpEventCopyWithImpl<$Res, _$SignUpFormPasswordChangedImpl>
    implements _$$SignUpFormPasswordChangedImplCopyWith<$Res> {
  __$$SignUpFormPasswordChangedImplCopyWithImpl(
      _$SignUpFormPasswordChangedImpl _value,
      $Res Function(_$SignUpFormPasswordChangedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? password = null,
  }) {
    return _then(_$SignUpFormPasswordChangedImpl(
      null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$SignUpFormPasswordChangedImpl
    with DiagnosticableTreeMixin
    implements _SignUpFormPasswordChanged {
  const _$SignUpFormPasswordChangedImpl(this.password);

  @override
  final String password;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SignUpEvent.signUpFormPasswordChanged(password: $password)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(
          DiagnosticsProperty('type', 'SignUpEvent.signUpFormPasswordChanged'))
      ..add(DiagnosticsProperty('password', password));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignUpFormPasswordChangedImpl &&
            (identical(other.password, password) ||
                other.password == password));
  }

  @override
  int get hashCode => Object.hash(runtimeType, password);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignUpFormPasswordChangedImplCopyWith<_$SignUpFormPasswordChangedImpl>
      get copyWith => __$$SignUpFormPasswordChangedImplCopyWithImpl<
          _$SignUpFormPasswordChangedImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) signUpFormUsernameChanged,
    required TResult Function(String password) signUpFormPasswordChanged,
    required TResult Function() signUpSubmitted,
    required TResult Function() reset,
  }) {
    return signUpFormPasswordChanged(password);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? signUpFormUsernameChanged,
    TResult? Function(String password)? signUpFormPasswordChanged,
    TResult? Function()? signUpSubmitted,
    TResult? Function()? reset,
  }) {
    return signUpFormPasswordChanged?.call(password);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? signUpFormUsernameChanged,
    TResult Function(String password)? signUpFormPasswordChanged,
    TResult Function()? signUpSubmitted,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (signUpFormPasswordChanged != null) {
      return signUpFormPasswordChanged(password);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SignUpFormUsernameChanged value)
        signUpFormUsernameChanged,
    required TResult Function(_SignUpFormPasswordChanged value)
        signUpFormPasswordChanged,
    required TResult Function(_SignUpSubmitted value) signUpSubmitted,
    required TResult Function(_SignUpReset value) reset,
  }) {
    return signUpFormPasswordChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult? Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult? Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult? Function(_SignUpReset value)? reset,
  }) {
    return signUpFormPasswordChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult Function(_SignUpReset value)? reset,
    required TResult orElse(),
  }) {
    if (signUpFormPasswordChanged != null) {
      return signUpFormPasswordChanged(this);
    }
    return orElse();
  }
}

abstract class _SignUpFormPasswordChanged implements SignUpEvent {
  const factory _SignUpFormPasswordChanged(final String password) =
      _$SignUpFormPasswordChangedImpl;

  String get password;
  @JsonKey(ignore: true)
  _$$SignUpFormPasswordChangedImplCopyWith<_$SignUpFormPasswordChangedImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$SignUpSubmittedImplCopyWith<$Res> {
  factory _$$SignUpSubmittedImplCopyWith(_$SignUpSubmittedImpl value,
          $Res Function(_$SignUpSubmittedImpl) then) =
      __$$SignUpSubmittedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SignUpSubmittedImplCopyWithImpl<$Res>
    extends _$SignUpEventCopyWithImpl<$Res, _$SignUpSubmittedImpl>
    implements _$$SignUpSubmittedImplCopyWith<$Res> {
  __$$SignUpSubmittedImplCopyWithImpl(
      _$SignUpSubmittedImpl _value, $Res Function(_$SignUpSubmittedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SignUpSubmittedImpl
    with DiagnosticableTreeMixin
    implements _SignUpSubmitted {
  const _$SignUpSubmittedImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SignUpEvent.signUpSubmitted()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'SignUpEvent.signUpSubmitted'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SignUpSubmittedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) signUpFormUsernameChanged,
    required TResult Function(String password) signUpFormPasswordChanged,
    required TResult Function() signUpSubmitted,
    required TResult Function() reset,
  }) {
    return signUpSubmitted();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? signUpFormUsernameChanged,
    TResult? Function(String password)? signUpFormPasswordChanged,
    TResult? Function()? signUpSubmitted,
    TResult? Function()? reset,
  }) {
    return signUpSubmitted?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? signUpFormUsernameChanged,
    TResult Function(String password)? signUpFormPasswordChanged,
    TResult Function()? signUpSubmitted,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (signUpSubmitted != null) {
      return signUpSubmitted();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SignUpFormUsernameChanged value)
        signUpFormUsernameChanged,
    required TResult Function(_SignUpFormPasswordChanged value)
        signUpFormPasswordChanged,
    required TResult Function(_SignUpSubmitted value) signUpSubmitted,
    required TResult Function(_SignUpReset value) reset,
  }) {
    return signUpSubmitted(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult? Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult? Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult? Function(_SignUpReset value)? reset,
  }) {
    return signUpSubmitted?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult Function(_SignUpReset value)? reset,
    required TResult orElse(),
  }) {
    if (signUpSubmitted != null) {
      return signUpSubmitted(this);
    }
    return orElse();
  }
}

abstract class _SignUpSubmitted implements SignUpEvent {
  const factory _SignUpSubmitted() = _$SignUpSubmittedImpl;
}

/// @nodoc
abstract class _$$SignUpResetImplCopyWith<$Res> {
  factory _$$SignUpResetImplCopyWith(
          _$SignUpResetImpl value, $Res Function(_$SignUpResetImpl) then) =
      __$$SignUpResetImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$SignUpResetImplCopyWithImpl<$Res>
    extends _$SignUpEventCopyWithImpl<$Res, _$SignUpResetImpl>
    implements _$$SignUpResetImplCopyWith<$Res> {
  __$$SignUpResetImplCopyWithImpl(
      _$SignUpResetImpl _value, $Res Function(_$SignUpResetImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$SignUpResetImpl with DiagnosticableTreeMixin implements _SignUpReset {
  const _$SignUpResetImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SignUpEvent.reset()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'SignUpEvent.reset'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$SignUpResetImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) signUpFormUsernameChanged,
    required TResult Function(String password) signUpFormPasswordChanged,
    required TResult Function() signUpSubmitted,
    required TResult Function() reset,
  }) {
    return reset();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? signUpFormUsernameChanged,
    TResult? Function(String password)? signUpFormPasswordChanged,
    TResult? Function()? signUpSubmitted,
    TResult? Function()? reset,
  }) {
    return reset?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? signUpFormUsernameChanged,
    TResult Function(String password)? signUpFormPasswordChanged,
    TResult Function()? signUpSubmitted,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_SignUpFormUsernameChanged value)
        signUpFormUsernameChanged,
    required TResult Function(_SignUpFormPasswordChanged value)
        signUpFormPasswordChanged,
    required TResult Function(_SignUpSubmitted value) signUpSubmitted,
    required TResult Function(_SignUpReset value) reset,
  }) {
    return reset(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult? Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult? Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult? Function(_SignUpReset value)? reset,
  }) {
    return reset?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_SignUpFormUsernameChanged value)?
        signUpFormUsernameChanged,
    TResult Function(_SignUpFormPasswordChanged value)?
        signUpFormPasswordChanged,
    TResult Function(_SignUpSubmitted value)? signUpSubmitted,
    TResult Function(_SignUpReset value)? reset,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset(this);
    }
    return orElse();
  }
}

abstract class _SignUpReset implements SignUpEvent {
  const factory _SignUpReset() = _$SignUpResetImpl;
}

/// @nodoc
mixin _$SignUpState {
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;
  UsernameDataFieldModel get usernameDataFieldModel =>
      throw _privateConstructorUsedError;
  PasswordFieldModel get passwordFieldModel =>
      throw _privateConstructorUsedError;
  SignUpError get error => throw _privateConstructorUsedError;
  bool get isValid => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $SignUpStateCopyWith<SignUpState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SignUpStateCopyWith<$Res> {
  factory $SignUpStateCopyWith(
          SignUpState value, $Res Function(SignUpState) then) =
      _$SignUpStateCopyWithImpl<$Res, SignUpState>;
  @useResult
  $Res call(
      {FormzSubmissionStatus status,
      UsernameDataFieldModel usernameDataFieldModel,
      PasswordFieldModel passwordFieldModel,
      SignUpError error,
      bool isValid});
}

/// @nodoc
class _$SignUpStateCopyWithImpl<$Res, $Val extends SignUpState>
    implements $SignUpStateCopyWith<$Res> {
  _$SignUpStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? usernameDataFieldModel = null,
    Object? passwordFieldModel = null,
    Object? error = null,
    Object? isValid = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      usernameDataFieldModel: null == usernameDataFieldModel
          ? _value.usernameDataFieldModel
          : usernameDataFieldModel // ignore: cast_nullable_to_non_nullable
              as UsernameDataFieldModel,
      passwordFieldModel: null == passwordFieldModel
          ? _value.passwordFieldModel
          : passwordFieldModel // ignore: cast_nullable_to_non_nullable
              as PasswordFieldModel,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as SignUpError,
      isValid: null == isValid
          ? _value.isValid
          : isValid // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SignUpStateImplCopyWith<$Res>
    implements $SignUpStateCopyWith<$Res> {
  factory _$$SignUpStateImplCopyWith(
          _$SignUpStateImpl value, $Res Function(_$SignUpStateImpl) then) =
      __$$SignUpStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {FormzSubmissionStatus status,
      UsernameDataFieldModel usernameDataFieldModel,
      PasswordFieldModel passwordFieldModel,
      SignUpError error,
      bool isValid});
}

/// @nodoc
class __$$SignUpStateImplCopyWithImpl<$Res>
    extends _$SignUpStateCopyWithImpl<$Res, _$SignUpStateImpl>
    implements _$$SignUpStateImplCopyWith<$Res> {
  __$$SignUpStateImplCopyWithImpl(
      _$SignUpStateImpl _value, $Res Function(_$SignUpStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? usernameDataFieldModel = null,
    Object? passwordFieldModel = null,
    Object? error = null,
    Object? isValid = null,
  }) {
    return _then(_$SignUpStateImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      usernameDataFieldModel: null == usernameDataFieldModel
          ? _value.usernameDataFieldModel
          : usernameDataFieldModel // ignore: cast_nullable_to_non_nullable
              as UsernameDataFieldModel,
      passwordFieldModel: null == passwordFieldModel
          ? _value.passwordFieldModel
          : passwordFieldModel // ignore: cast_nullable_to_non_nullable
              as PasswordFieldModel,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as SignUpError,
      isValid: null == isValid
          ? _value.isValid
          : isValid // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$SignUpStateImpl with DiagnosticableTreeMixin implements _SignUpState {
  const _$SignUpStateImpl(
      {required this.status,
      required this.usernameDataFieldModel,
      required this.passwordFieldModel,
      required this.error,
      required this.isValid});

  @override
  final FormzSubmissionStatus status;
  @override
  final UsernameDataFieldModel usernameDataFieldModel;
  @override
  final PasswordFieldModel passwordFieldModel;
  @override
  final SignUpError error;
  @override
  final bool isValid;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'SignUpState(status: $status, usernameDataFieldModel: $usernameDataFieldModel, passwordFieldModel: $passwordFieldModel, error: $error, isValid: $isValid)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'SignUpState'))
      ..add(DiagnosticsProperty('status', status))
      ..add(
          DiagnosticsProperty('usernameDataFieldModel', usernameDataFieldModel))
      ..add(DiagnosticsProperty('passwordFieldModel', passwordFieldModel))
      ..add(DiagnosticsProperty('error', error))
      ..add(DiagnosticsProperty('isValid', isValid));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SignUpStateImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.usernameDataFieldModel, usernameDataFieldModel) ||
                other.usernameDataFieldModel == usernameDataFieldModel) &&
            (identical(other.passwordFieldModel, passwordFieldModel) ||
                other.passwordFieldModel == passwordFieldModel) &&
            (identical(other.error, error) || other.error == error) &&
            (identical(other.isValid, isValid) || other.isValid == isValid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, usernameDataFieldModel,
      passwordFieldModel, error, isValid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$SignUpStateImplCopyWith<_$SignUpStateImpl> get copyWith =>
      __$$SignUpStateImplCopyWithImpl<_$SignUpStateImpl>(this, _$identity);
}

abstract class _SignUpState implements SignUpState {
  const factory _SignUpState(
      {required final FormzSubmissionStatus status,
      required final UsernameDataFieldModel usernameDataFieldModel,
      required final PasswordFieldModel passwordFieldModel,
      required final SignUpError error,
      required final bool isValid}) = _$SignUpStateImpl;

  @override
  FormzSubmissionStatus get status;
  @override
  UsernameDataFieldModel get usernameDataFieldModel;
  @override
  PasswordFieldModel get passwordFieldModel;
  @override
  SignUpError get error;
  @override
  bool get isValid;
  @override
  @JsonKey(ignore: true)
  _$$SignUpStateImplCopyWith<_$SignUpStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
