part of 'sign_up_bloc.dart';

@freezed
class SignUpEvent with _$SignUpEvent {
  const factory SignUpEvent.signUpFormUsernameChanged(
    String username,
  ) = _SignUpFormUsernameChanged;
  const factory SignUpEvent.signUpFormPasswordChanged(String password) =
      _SignUpFormPasswordChanged;
  const factory SignUpEvent.signUpSubmitted() = _SignUpSubmitted;
  const factory SignUpEvent.reset() = _SignUpReset;
}
