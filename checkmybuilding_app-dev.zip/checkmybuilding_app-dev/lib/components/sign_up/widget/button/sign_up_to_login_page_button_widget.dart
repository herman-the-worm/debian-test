import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/navigation/router_go.dart';
import 'package:flutter/material.dart';

class SignUpToLoginPageButtonWidget extends StatelessWidget {
  const SignUpToLoginPageButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: TextButton(
        key: signUp_goToLogIn_buttonWidgetKey,
        onPressed: () => _onSignUpTap(context),
        child: const Text(
          'Back to Login',
          style: KCustomTextTheme.textAccentButtonStyle,
        ),
      ),
    );
  }
}

void _onSignUpTap(BuildContext context) {
  router.go(KRouteStatic.login.path);
}
