import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignUpToCompleteButtonWidget extends StatelessWidget {
  const SignUpToCompleteButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignUpBloc, SignUpState>(
      buildWhen: (previous, current) => previous != current,
      builder: (context, state) {
        return SizedBox(
          width: kWidgetWidthXL,
          child: TextButton(
            key: signUp_submit_buttonWidgetKey,
            onPressed: state.isValid
                ? () => context
                    .read<SignUpBloc>()
                    .add(const SignUpEvent.signUpSubmitted())
                : null,
            style: TextButton.styleFrom(
              backgroundColor: state.isValid
                  ? KCustomColorTheme.kDarkGrey
                  : KCustomColorTheme.kLightGrey,
              minimumSize: const Size(188, 49),
              padding: const EdgeInsets.all(
                KPaddingSizeStatic.kPaddingSizeXSS,
              ),
              shape: const RoundedRectangleBorder(
                  // borderRadius: BorderRadius.circular(0),
                  ),
            ),
            child: const Text(
              'Complete',
              style: KCustomTextTheme.textStyleBlackMain,
            ),
          ),
        );
      },
    );
  }
}
