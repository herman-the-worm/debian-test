import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/models/field_models/password_field_model.dart';
import 'package:checkmybuilding/shared/widget/text_field_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignUpFormPasswordFieldWidget extends StatefulWidget {
  const SignUpFormPasswordFieldWidget({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _SignUpFormPasswordFieldWidgetState createState() =>
      _SignUpFormPasswordFieldWidgetState();
}

class _SignUpFormPasswordFieldWidgetState
    extends State<SignUpFormPasswordFieldWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _hidePassword = true;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignUpBloc, SignUpState>(
      buildWhen: (previous, current) =>
          previous.passwordFieldModel != current.passwordFieldModel,
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFieldWidget(
              focusNode: _focusNode,
              controller: _controller,
              widgetKey: signUp_passwordInput_textFieldWidgetKey,
              textAlign: TextAlign.left,
              onChanged: (value) => context
                  .read<SignUpBloc>()
                  .add(SignUpEvent.signUpFormPasswordChanged(value)),
              border: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              obscureText: _hidePassword,
              suffixIcon: IconButton(
                onPressed: () => setState(
                  () => _hidePassword = !_hidePassword,
                ),
                icon: _hidePassword
                    ? const Icon(
                        Icons.visibility_off,
                        color: KCustomColorTheme.kBlack,
                      )
                    : const Icon(
                        Icons.visibility,
                        color: KCustomColorTheme.kBlack,
                      ),
              ),
              fillColor: KCustomColorTheme.kLightGrey,
              hintText: 'Password',
              errorText: _passwordError(state.passwordFieldModel),
              width: kWidgetWidthXXL,
            ),
          ],
        );
      },
    );
  }

  String? _passwordError(PasswordFieldModel value) {
    if (value.isPure) {
      return null;
    }
    if (value.error == PasswordFieldModelValidationError.empty) {
      return 'Password cannot be empty';
    }
    // if (value.error == PasswordFieldModelValidationError.eightCharacter) {
    //   return 'Password must be at least 8 characters';
    // }
    // if (value.error == PasswordFieldModelValidationError.capitalLetter) {
    //   return 'Password must include at least one capital letter';
    // }
    // if (value.error == PasswordFieldModelValidationError.oneNumber) {
    //   return 'Password must include at least one number';
    // }

    return null;
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
