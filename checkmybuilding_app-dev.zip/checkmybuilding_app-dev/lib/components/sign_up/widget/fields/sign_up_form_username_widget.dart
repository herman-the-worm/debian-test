import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SignUpFormUsernameFieldWidget extends StatefulWidget {
  const SignUpFormUsernameFieldWidget({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _SignUpFormUsernameFieldWidgetState createState() =>
      _SignUpFormUsernameFieldWidgetState();
}

class _SignUpFormUsernameFieldWidgetState
    extends State<SignUpFormUsernameFieldWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignUpBloc, SignUpState>(
      buildWhen: (previous, current) =>
          previous.usernameDataFieldModel != current.usernameDataFieldModel,
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFieldWidget(
              focusNode: _focusNode,
              controller: _controller,
              widgetKey: signUp_usernameInput_textFieldWidgetKey,
              textAlign: TextAlign.left,
              onChanged: (value) => context
                  .read<SignUpBloc>()
                  .add(SignUpEvent.signUpFormUsernameChanged(value)),
              border: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              fillColor: KCustomColorTheme.kLightGrey,
              hintText: 'Username',
              errorText: _passwordError(state.usernameDataFieldModel),
              width: kWidgetWidthXXL,
            ),
          ],
        );
      },
    );
  }

  String? _passwordError(UsernameDataFieldModel value) {
    if (value.isPure) {
      return null;
    }
    if (value.error == UsernameDataFieldModelValidationError.empty) {
      return 'Username cannot be empty';
    }

    return null;
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
