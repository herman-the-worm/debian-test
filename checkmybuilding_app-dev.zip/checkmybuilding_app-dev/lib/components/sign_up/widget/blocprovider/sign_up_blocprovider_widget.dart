import 'package:checkmybuilding/components/sign_up/bloc/bloc/sign_up_bloc.dart';
import 'package:checkmybuilding/l10n/l10n.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:formz/formz.dart';
import 'package:go_router/go_router.dart';

class SignUpBlocProviderWidget extends StatelessWidget {
  const SignUpBlocProviderWidget({required this.childWidget, super.key});
  final Widget childWidget;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt.get<SignUpBloc>(),
      child: SignUpBlocProviderAdditionalWidget(childWidget: childWidget),
    );
  }
}

class SignUpBlocProviderAdditionalWidget extends StatelessWidget {
  const SignUpBlocProviderAdditionalWidget({
    required this.childWidget,
    super.key,
  });

  final Widget childWidget;

  @override
  Widget build(BuildContext context) {
    return BlocListener<SignUpBloc, SignUpState>(
      listener: (context, state) {
        if (state.status.isFailure && state.error == SignUpError.error) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                content: Text(
                  AppLocalizations.of(context)
                      .authenticationFailure
                      .toTitleCase(),
                ),
              ),
            );
        }
        if (state.status.isSuccess) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                content: Text(
                  AppLocalizations.of(context)
                      .authenticationSuccess
                      .toTitleCase(),
                ),
              ),
            );
          context.read<AuthenticationBloc>().add(
                const AuthenticationStatusChanged(
                  AuthenticationStatus.authenticated,
                ),
              );
          context.go(KRouteStatic.home.path);
        }
      },
      child: childWidget,
    );
  }
}
