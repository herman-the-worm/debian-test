import 'package:checkmybuilding/components/sign_up/already_have_an_account_text_widget.dart';
import 'package:checkmybuilding/components/sign_up/widget/button/sign_up_to_login_page_button_widget.dart';
import 'package:checkmybuilding/components/sign_up/widget/widget.dart';
import 'package:checkmybuilding/shared/constants/text_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:checkmybuilding/shared/constants/widgets_constant.dart';
import 'package:checkmybuilding/shared/widget/divider_row_widget.dart';
import 'package:checkmybuilding/shared/widget/title_text_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class SignUpBodyWidget extends StatefulWidget {
  const SignUpBodyWidget({super.key});

  @override
  State<SignUpBodyWidget> createState() => _SignUpBodyWidgetState();
}

class _SignUpBodyWidgetState extends State<SignUpBodyWidget> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(
          left: KPaddingSizeStatic.kPaddingSizeXL,
          right: KPaddingSizeStatic.kPaddingSizeXL,
        ),
        child: ListView(
          physics: kIsWeb ? const NeverScrollableScrollPhysics() : null,
          children: const [
            Column(
              children: [
                SizedBoxStatic.kHeightSizedBoxM,
                Center(
                  child: TitleTextWidget(
                    title: 'Sign Up',
                    key: signUp_formTitleSignUp_textWidgetKey,
                    style: KCustomTextTheme.textStyleBlackMain,
                  ),
                ),
                SizedBoxStatic.kHeightSizedBoxL,
                Center(child: SignUpFormUsernameFieldWidget()),
                SizedBoxStatic.kHeightSizedBoxS,
                Center(child: SignUpFormPasswordFieldWidget()),
                SizedBoxStatic.kHeightSizedBoxM,
                SignUpToCompleteButtonWidget(),
                Padding(
                  padding: EdgeInsets.only(
                    left: KPaddingSizeStatic.kPaddingSizeSM,
                    right: KPaddingSizeStatic.kPaddingSizeSM,
                    top: KPaddingSizeStatic.kPaddingSizeS,
                  ),
                  child: DividerRowWidget(),
                ),
                SizedBoxStatic.kHeightSizedBoxS,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AlreadyHaveAnAccTextWidget(),
                    SignUpToLoginPageButtonWidget(),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
