import 'package:checkmybuilding/l10n/l10n.dart';
import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ErrorBodyWidget extends StatelessWidget {
  const ErrorBodyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton(
        onPressed: () => context.go(KRouteStatic.home.path),
        child: Text(AppLocalizations.of(context).goToHomePage),
      ),
    );
  }
}
