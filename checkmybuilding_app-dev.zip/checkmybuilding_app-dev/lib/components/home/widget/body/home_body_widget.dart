import 'package:checkmybuilding/components/home/widget/widget.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class HomePageBodyWidget extends StatelessWidget {
  const HomePageBodyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            // Define the minimum height threshold
            const minHeightThreshold = 300; // Replace with your desired height

            // Check if the height is less than the threshold
            final isHeightLessThanThreshold =
                constraints.maxHeight < minHeightThreshold;

            // Conditional rendering based on the height
            return isHeightLessThanThreshold
                ? const SizedBox()
                : isWebMobile
                    ? const SizedBox()
                    : const IconsColumnWidget();
          },
        ),
        Expanded(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  top: KPaddingSizeStatic.kPaddingSizeML,
                  bottom: KPaddingSizeStatic.kPaddingSizeML,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SquareButtonWidget(
                      key: home_createNewAudit_buttonWidgetKey,
                      buttonNaming: 'Create new audit',
                      buttonIcon: Icons.add,
                      onTap: () => showCustomDialog(context),
                    ),
                    SizedBoxStatic.kWidthSizedBoxM,
                    SquareButtonWidget(
                      key: home_celendarOfAudits_buttonWidgetKey,
                      buttonIcon: Icons.date_range,
                      buttonNaming: 'Calendar of audits',
                      onTap: () {},
                    ),
                  ],
                ),
              ),
              const SeparatorWithTextWidget(
                separatorTitle: 'My audits',
                width: kWidgetWidthXXL,
                height: kWidgetHeightM,
              ),
              SizedBoxStatic.kHeightSizedBoxM,
              const Expanded(
                child: HomeListOfAuditsWidget(),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
