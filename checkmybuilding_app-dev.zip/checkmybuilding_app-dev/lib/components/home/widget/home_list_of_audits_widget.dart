import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/widget/text_description_widget.dart';
import 'package:flutter/material.dart';

class HomeListOfAuditsWidget extends StatelessWidget {
  const HomeListOfAuditsWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(
        maxWidth: maxWidthLarge,
      ),
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(
          horizontal: KPaddingSizeStatic.kPaddingSizeM,
        ),
        itemExtent: 100,
        itemCount: 10,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: const EdgeInsets.all(
              KPaddingSizeStatic.kPaddingSizeXSS,
            ),
            child: Container(
              key: index == 9
                  ? home_itemAuditLast_widgetKey
                  : home_itemAudit_widgetKey,
              decoration: const BoxDecoration(
                color: KCustomColorTheme.kGrey,
                boxShadow: [
                  BoxShadow(
                    color: KCustomColorTheme.kBlackWithOpacity,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: const ListTile(
                leading: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextDescriptionWidget(
                      title: '#23456',
                    ),
                    TextDescriptionWidget(
                      title: 'Canada',
                    ),
                    TextDescriptionWidget(
                      title: 'Status',
                    ),
                  ],
                ),
                trailing: Column(
                  children: [
                    TextDescriptionWidget(
                      title: '11/4/23',
                    ),
                    TextDescriptionWidget(
                      title: 'Does not repeat',
                    ),
                  ],
                ),
              ),
            ),
          );
          // return Padding(
          //     padding: const EdgeInsets.symmetric(horizontal: 16, vertical:
          //     child: Container(
          //       width: 200,
          //       decoration: BoxDecoration(
          //         color: const Color.fromRGBO(217, 217, 217, 1),
          //         boxShadow: [
          //           BoxShadow(
          //             color: Colors.black.withOpacity(0.4),
          //             blurRadius: 8,
          //             offset: const Offset(0, 2),
          //           ),
          //         ],
          //       ),
          //       clipBehavior: Clip.hardEdge,
          //       child: const ListTile(
          //           title: Column(
          //             children: [
          //               Text('#112823'),
          //               Text('Canada'),
          //               Text('Status'),
          //             ],
          //           ),
          //           trailing: Column(
          //             children: [
          //               Text('Date'),
          //               Text('Time'),
          //             ],
          //           )),
          //     )
          //     // const Column(
          //     //   children: [
          //     //     ItemNumberRowWidget(),
          //     //     ItemNameRowWidget(),
          //     //     ItemStatusRowWidget(),
          //     //   ],
          //     // ),

          //     );
        },
      ),
    );
  }
}
