import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:checkmybuilding/shared/widget/custom_icon_button_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class IconsColumnWidget extends StatelessWidget {
  const IconsColumnWidget({
    super.key,
    this.isSmall,
  });
  final bool? isSmall;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Column(
          key: home_iconsColumn_buttonsWidgetKey,
          children: [
            CustomIconButtonWidget(
              width: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              height: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              buttonNaming: KRouteStatic.home.name,
              buttonIcon: Icons.home,
              onTap: () => KRouteStatic.home.path,
            ),
            CustomIconButtonWidget(
              width: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              height: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              buttonNaming: KRouteStatic.profile.name,
              buttonIcon: Icons.person,
              onTap: () => KRouteStatic.profile.path,
            ),
            CustomIconButtonWidget(
              width: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              height: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              buttonNaming: KRouteStatic.template.name,
              buttonIcon: Icons.book,
              onTap: () => KRouteStatic.template.path,
            ),
            CustomIconButtonWidget(
              width: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              height: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              buttonNaming: KRouteStatic.support.name,
              buttonIcon: Icons.support,
              onTap: () => KRouteStatic.support.path,
            ),
            CustomIconButtonWidget(
              key: home_logOutButton_widgetKey,
              width: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              height: isSmall == null ? kWidgetWidthM : kWidgetWidthS,
              buttonNaming: KRouteStatic.logOut.name,
              buttonIcon: Icons.logout,
              onTap: () => context.read<AuthenticationBloc>().add(
                    AuthenticationLogoutRequested(),
                  ),
            ),
          ],
        ),
      ],
    );
  }
}
