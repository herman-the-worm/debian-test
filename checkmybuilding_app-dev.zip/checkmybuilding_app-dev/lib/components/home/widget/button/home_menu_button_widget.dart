import 'package:flutter/material.dart';

class HomeMenuButtonWidget extends StatelessWidget {
  const HomeMenuButtonWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () => Scaffold.of(context).openEndDrawer(),
      icon: const Icon(
        Icons.menu,
        color: Colors.black,
      ),
    );
  }
}
