import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/constants/text_theme_constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LogOutButtonWidget extends StatelessWidget {
  const LogOutButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthenticationBloc, AuthenticationState>(
      buildWhen: (previous, current) => previous != current,
      builder: (context, state) {
        return TextButton(
          onPressed: () => context.read<AuthenticationBloc>().add(
                AuthenticationLogoutRequested(),
              ),
          child: const Text(
            'LogOut',
            style: KCustomTextTheme.textAccentButtonStyle,
          ),
        );
      },
    );
  }
}
