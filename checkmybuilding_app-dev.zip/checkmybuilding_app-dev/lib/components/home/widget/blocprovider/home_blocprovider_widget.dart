import 'package:flutter/material.dart';

class HomeBlocProviderWidget extends StatelessWidget {
  const HomeBlocProviderWidget({required this.childWidget, super.key});
  final Widget childWidget;

  @override
  Widget build(BuildContext context) {
    return childWidget;
  }
}
