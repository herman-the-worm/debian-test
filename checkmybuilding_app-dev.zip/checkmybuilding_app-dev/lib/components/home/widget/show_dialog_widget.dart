import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/route_constant.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:checkmybuilding/shared/constants/widgets_constant.dart';
import 'package:checkmybuilding/shared/widget/square_button_widget.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

void showCustomDialog(BuildContext context) {
  showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        icon: Align(
          alignment: Alignment.topRight,
          child: IconButton(
            icon: const Icon(Icons.close),
            color: KCustomColorTheme.kBlack,
            onPressed: () => context.pop(),
          ),
        ),
        key: homeState_showCustomDialog_WidgetKey,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(0),
        ),
        content: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SquareButtonWidget(
              key: homeState_showCustomDialog_useTemplate_buttonWidgetKey,
              buttonNaming: 'Use template',
              buttonIcon: Icons.add,
              onTap: () => context.go(KRouteStatic.template.path),
            ),
            SizedBoxStatic.kWidthSizedBoxM,
            SquareButtonWidget(
              buttonNaming: 'Create your own template',
              buttonIcon: Icons.calendar_today,
              onTap: () {},
            ),
          ],
        ),
      );
    },
  );
}
