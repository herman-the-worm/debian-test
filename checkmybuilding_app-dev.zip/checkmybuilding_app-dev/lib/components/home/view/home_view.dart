import 'package:checkmybuilding/components/home/widget/button/home_menu_button_widget.dart';
import 'package:checkmybuilding/components/home/widget/widget.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:checkmybuilding/shared/widget/drawer_widget.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      endDrawer: const DrawerWidget(),
      appBar: AppBar(
        backgroundColor: KCustomColorTheme.kDarkGrey,
        centerTitle: true,
        title: const Center(
          child: Text(
            'Logo!',
            style: KCustomTextTheme.textStyleBlackMain,
          ),
        ),
        actions: const [
          //   if (isWebMobile)
          HomeMenuButtonWidget(),
        ],
      ),
      body: const HomeBlocProviderWidget(
        childWidget: HomePageBodyWidget(),
      ),
    );
  }
}
