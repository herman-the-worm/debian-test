import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/l10n/l10n.dart';
import 'package:checkmybuilding/shared/bloc/authentication/authentication_bloc.dart';
import 'package:checkmybuilding/shared/helper/get_it_service_locator.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:formz/formz.dart';
import 'package:go_router/go_router.dart';

class LoginBlocProviderWidget extends StatelessWidget {
  const LoginBlocProviderWidget({required this.childWidget, super.key});
  final Widget childWidget;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => getIt.get<LoginBloc>(),
      child: LoginBlocProviderAdditionalWidget(childWidget: childWidget),
    );
  }
}

class LoginBlocProviderAdditionalWidget extends StatelessWidget {
  const LoginBlocProviderAdditionalWidget({
    required this.childWidget,
    super.key,
  });

  final Widget childWidget;

  @override
  Widget build(BuildContext context) {
    return BlocListener<LoginBloc, LoginState>(
      listener: (context, state) {
        if (state.status.isFailure && state.error == LoginError.error) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                content: Text(
                  AppLocalizations.of(context)
                      .authenticationFailure
                      .toTitleCase(),
                ),
              ),
            );
        }
        if (state.status.isSuccess) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                content: Text(
                  AppLocalizations.of(context)
                      .authenticationSuccess
                      .toTitleCase(),
                ),
              ),
            );
          context.read<AuthenticationBloc>().add(
                const AuthenticationStatusChanged(
                  AuthenticationStatus.authenticated,
                ),
              );
          context.go(KRouteStatic.home.path);
        }
      },
      child: childWidget,
    );
  }
}
