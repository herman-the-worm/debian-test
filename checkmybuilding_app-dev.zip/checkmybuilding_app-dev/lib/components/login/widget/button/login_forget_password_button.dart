import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class LoginFormForgetPasswordButtonWidget extends StatelessWidget {
  const LoginFormForgetPasswordButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {},
      key: logIn_formForgetPasswor_buttonWidgetKey,
      child: const Text(
        'Forgot password?',
        style: KCustomTextTheme.textStyleBlackMain,
      ),
    );
  }
}
