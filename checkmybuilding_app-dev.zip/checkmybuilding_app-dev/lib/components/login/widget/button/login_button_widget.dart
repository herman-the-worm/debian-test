import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginFormSubmitButtonWidget extends StatelessWidget {
  const LoginFormSubmitButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      buildWhen: (previous, current) => previous != current,
      builder: (context, state) {
        return SizedBox(
          width: kWidgetWidthXL,
          child: TextButton(
            key: logIn_submit_buttonWidgetKey,
            onPressed: state.isValid
                ? () {
                    context.read<LoginBloc>().add(
                          const LoginEvent.loginSubmitted(),
                        );
                  }
                : null,
            style: TextButton.styleFrom(
              backgroundColor: state.isValid
                  ? KCustomColorTheme.kDarkGrey
                  : KCustomColorTheme.kLightGrey,
              minimumSize: const Size(188, 49),
              padding: const EdgeInsets.all(
                KPaddingSizeStatic.kPaddingSizeXSS,
              ),
              shape: const RoundedRectangleBorder(
                  // borderRadius: BorderRadius.circular(0),
                  ),
            ),
            child: const Text(
              'Log In',
              style: KCustomTextTheme.textStyleBlackMain,
            ),
          ),
        );
      },
    );
  }
}
