import 'package:checkmybuilding/shared/constants/constants.dart';
import 'package:checkmybuilding/shared/navigation/router_go.dart';
import 'package:flutter/material.dart';

class LoginFormGoToSignUpButtonWidget extends StatelessWidget {
  const LoginFormGoToSignUpButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      // width: width * 0.9,
      child: TextButton(
        key: logIn_goToSignUp_buttonWidgetKey,
        onPressed: () => _onSignUpTap(context),
        child: const Text(
          'Sign Up',
          style: KCustomTextTheme.textAccentButtonStyle,
        ),
      ),
    );
  }
}

void _onSignUpTap(BuildContext context) {
  router.go(KRouteStatic.signUp.path);
}
