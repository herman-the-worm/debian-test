import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LoginGoogleSignInButtonWidget extends StatelessWidget {
  const LoginGoogleSignInButtonWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: SizedBox(
        child: ElevatedButton.icon(
          key: const Key('loginForm_googleLogin_raisedButton'),
          label: const Text(
            'SIGN IN WITH GOOGLE',
            style: KCustomTextTheme.textStyleWhiteLarge,
          ),
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(kBorderSideSizeL),
            ),
            backgroundColor: theme.colorScheme.secondary,
          ),
          icon: const Icon(
            FontAwesomeIcons.google,
            color: KCustomColorTheme.kWhite,
          ),
          onPressed: () => context.read<LoginBloc>().add(
                const LoginEvent.loginWithGoogle(),
              ),
        ),
      ),
    );
  }
}
