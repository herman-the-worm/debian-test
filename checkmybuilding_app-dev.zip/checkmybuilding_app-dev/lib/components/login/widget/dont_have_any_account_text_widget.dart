import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';

class DontHaveAnyAccTextWidget extends StatelessWidget {
  const DontHaveAnyAccTextWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const Text(
      "Don't have any account?",
      style: KCustomTextTheme.textStyleBlackMain,
      key: logIn_formDontHaveAnnyAcc_buttonWidgetKey,
    );
  }
}
