import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginFormPasswordFieldWidget extends StatefulWidget {
  const LoginFormPasswordFieldWidget({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _LoginFormPasswordFieldWidgetState createState() =>
      _LoginFormPasswordFieldWidgetState();
}

class _LoginFormPasswordFieldWidgetState
    extends State<LoginFormPasswordFieldWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _hidePassword = true;

  @override
  void initState() {
    super.initState();
    // if (!kReleaseMode) {
    //   _controller.text = 'qwerty';
    // }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      buildWhen: (previous, current) =>
          previous.passwordFieldModel != current.passwordFieldModel,
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFieldWidget(
              focusNode: _focusNode,
              controller: _controller,
              widgetKey: logIn_formPasswordInput_textFieldWidgetKey,
              textAlign: TextAlign.left,
              onChanged: (value) => context
                  .read<LoginBloc>()
                  .add(LoginEvent.loginFormPasswordChanged(value)),
              border: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              obscureText: _hidePassword,
              suffixIcon: IconButton(
                onPressed: () {
                  setState(() => _hidePassword = !_hidePassword);
                },
                icon: _hidePassword
                    ? const Icon(
                        Icons.visibility_off,
                        color: KCustomColorTheme.kBlack,
                      )
                    : const Icon(
                        Icons.visibility,
                        color: KCustomColorTheme.kBlack,
                      ),
              ),
              hintText: 'Password',
              errorText: _passwordError(state.passwordFieldModel),
              width: kWidgetWidthXXL,
              fillColor: KCustomColorTheme.kLightGrey,
            ),
          ],
        );
      },
    );
  }

  String? _passwordError(PasswordFieldModel value) {
    if (value.isPure) {
      return null;
    }
    if (value.error == PasswordFieldModelValidationError.empty) {
      return 'Password cannot be empty';
    }

    // if (value.error == PasswordFieldModelValidationError.eightCharacter) {
    //   return 'Password must be at least 8 characters';
    // }
    // if (value.error == PasswordFieldModelValidationError.capitalLetter) {
    //   return 'Password must include at least one capital letter';
    // }
    // if (value.error == PasswordFieldModelValidationError.oneNumber) {
    //   return 'Password must include at least one number';
    // }

    return null;
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
