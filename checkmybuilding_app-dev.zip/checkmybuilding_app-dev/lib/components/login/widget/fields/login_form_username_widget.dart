import 'package:checkmybuilding/components/login/bloc/login_bloc.dart';
import 'package:checkmybuilding/shared/shared.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginFormUsernameFieldWidget extends StatefulWidget {
  const LoginFormUsernameFieldWidget({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _LoginFormUsernameFieldWidgetState createState() =>
      _LoginFormUsernameFieldWidgetState();
}

class _LoginFormUsernameFieldWidgetState
    extends State<LoginFormUsernameFieldWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    // if (!kReleaseMode) {
    //   _controller.text = 'andreytest@gmail.com';
    // }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginBloc, LoginState>(
      buildWhen: (previous, current) =>
          previous.usernameDataFieldModel != current.usernameDataFieldModel,
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFieldWidget(
              focusNode: _focusNode,
              controller: _controller,
              widgetKey: logIn_formUsernameInput_textFieldWidgetKey,
              textAlign: TextAlign.left,
              onChanged: (value) => context
                  .read<LoginBloc>()
                  .add(LoginEvent.loginFormUsernameChanged(value)),
              border: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              enabledBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              focusedBorder: const OutlineInputBorder(
                borderSide: BorderSide(color: KCustomColorTheme.kTransparent),
                borderRadius: BorderRadius.zero,
              ),
              hintText: 'Username',
              errorText: _passwordError(state.usernameDataFieldModel),
              width: kWidgetWidthXXL,
              fillColor: KCustomColorTheme.kLightGrey,
            ),
          ],
        );
      },
    );
  }

  String? _passwordError(UsernameDataFieldModel value) {
    if (value.isPure) {
      return null;
    }
    if (value.error == UsernameDataFieldModelValidationError.empty) {
      return 'Username cannot be empty';
    }

    return null;
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
