import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/components/login/widget/button/login_forget_password_button.dart';
import 'package:checkmybuilding/components/login/widget/dont_have_any_account_text_widget.dart';
import 'package:checkmybuilding/shared/constants/text_theme_constant.dart';
import 'package:checkmybuilding/shared/constants/widget_keys.dart';
import 'package:checkmybuilding/shared/constants/widgets_constant.dart';
import 'package:checkmybuilding/shared/widget/divider_row_widget.dart';
import 'package:checkmybuilding/shared/widget/title_text_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class LoginBodyWidget extends StatefulWidget {
  const LoginBodyWidget({super.key});

  @override
  State<LoginBodyWidget> createState() => _LoginBodyWidgetState();
}

class _LoginBodyWidgetState extends State<LoginBodyWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        left: KPaddingSizeStatic.kPaddingSizeXL,
        right: KPaddingSizeStatic.kPaddingSizeXL,
      ),
      child: ListView(
        physics: kIsWeb ? const NeverScrollableScrollPhysics() : null,
        children: const [
          SizedBoxStatic.kHeightSizedBoxM,
          Center(
            child: TitleTextWidget(
              title: 'Log In',
              key: logIn_formTitleLogin_textWidgetKey,
              style: KCustomTextTheme.textStyleBlackMain,
            ),
          ),
          SizedBoxStatic.kHeightSizedBoxL,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: LoginFormUsernameFieldWidget()),
              SizedBoxStatic.kHeightSizedBoxS,
              Center(child: LoginFormPasswordFieldWidget()),
              Center(child: LoginFormForgetPasswordButtonWidget()),
              Center(child: LoginFormSubmitButtonWidget()),
              SizedBoxStatic.kHeightSizedBoxS,
              Padding(
                padding: EdgeInsets.only(
                  left: KPaddingSizeStatic.kPaddingSizeSM,
                  right: KPaddingSizeStatic.kPaddingSizeSM,
                  top: KPaddingSizeStatic.kPaddingSizeS,
                ),
                child: DividerRowWidget(),
              ),
              SizedBoxStatic.kHeightSizedBoxS,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  DontHaveAnyAccTextWidget(),
                  LoginFormGoToSignUpButtonWidget(),
                ],
              ),
              SizedBoxStatic.kHeightSizedBoxS,
              LoginGoogleSignInButtonWidget(),
            ],
          ),
        ],
      ),
    );
  }
}
