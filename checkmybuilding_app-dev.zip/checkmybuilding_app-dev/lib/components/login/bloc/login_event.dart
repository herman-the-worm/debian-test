part of 'login_bloc.dart';

@freezed
class LoginEvent with _$LoginEvent {
  const factory LoginEvent.loginFormUsernameChanged(
    String username,
  ) = _LoginFormUsernameChanged;
  const factory LoginEvent.loginFormPasswordChanged(String password) =
      _LoginFormPasswordChanged;
  const factory LoginEvent.loginSubmitted() = _LoginSubmitted;
  const factory LoginEvent.loginWithGoogle() = _LoginWithGoogle;
  const factory LoginEvent.reset() = _LoginReset;
}
