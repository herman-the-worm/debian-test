import 'package:bloc/bloc.dart';
import 'package:checkmybuilding/shared/models/models.dart';
import 'package:checkmybuilding/shared/repository/authentication_repository.dart';
import 'package:flutter/foundation.dart';
import 'package:formz/formz.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';

part 'login_bloc.freezed.dart';
part 'login_event.dart';
part 'login_state.dart';

@Injectable()
class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginBloc(this._authenticationRepository)
      : super(
          const LoginState(
            status: FormzSubmissionStatus.initial,
            usernameDataFieldModel: UsernameDataFieldModel.pure(),
            passwordFieldModel: PasswordFieldModel.pure(),
            error: LoginError.initial,
            isValid: false,
          ),
        ) {
    on<_LoginFormUsernameChanged>(_onLoginFormUsernameChanged);
    on<_LoginFormPasswordChanged>(_onLoginFormPasswordChanged);
    on<_LoginSubmitted>(_onLoginSubmitted);
    on<_LoginReset>(_onLoginReset);
    on<_LoginWithGoogle>(_onLoginWithGoogle);
    // on<_LogOut>(_onLogOut);
  }
  final AuthenticationRepository _authenticationRepository;

  Future<void> _onLoginFormUsernameChanged(
    _LoginFormUsernameChanged event,
    Emitter<LoginState> emit,
  ) async {
    final usernameDataFieldModel = UsernameDataFieldModel.dirty(event.username);
    emit(
      state.copyWith(
        usernameDataFieldModel: usernameDataFieldModel,
        isValid: Formz.validate([
          usernameDataFieldModel,
          state.passwordFieldModel,
        ]),
      ),
    );
  }

  Future<void> _onLoginFormPasswordChanged(
    _LoginFormPasswordChanged event,
    Emitter<LoginState> emit,
  ) async {
    final passwordFieldModel = PasswordFieldModel.dirty(event.password);
    emit(
      state.copyWith(
        passwordFieldModel: passwordFieldModel,
        isValid: Formz.validate([
          passwordFieldModel,
          state.usernameDataFieldModel,
        ]),
      ),
    );
  }

  Future<void> _onLoginSubmitted(
    _LoginSubmitted event,
    Emitter<LoginState> emit,
  ) async {
    if (state.isValid) {
      emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
      try {
        final result = await _authenticationRepository.logIn(
          username: state.usernameDataFieldModel.value!,
          password: state.passwordFieldModel.value,
        );

        result
            ? emit(state.copyWith(status: FormzSubmissionStatus.success))
            : emit(state.copyWith(status: FormzSubmissionStatus.failure));
      } on Exception catch (e) {
        debugPrint(e.toString());
        emit(state.copyWith(status: FormzSubmissionStatus.failure));
      }
    }
  }

  Future<void> _onLoginReset(
    _LoginReset event,
    Emitter<LoginState> emit,
  ) async {
    emit(
      state.copyWith(
        status: FormzSubmissionStatus.initial,
        usernameDataFieldModel: const UsernameDataFieldModel.pure(),
        passwordFieldModel: const PasswordFieldModel.pure(),
        error: LoginError.initial,
      ),
    );
  }

  Future<void> _onLoginWithGoogle(
    _LoginWithGoogle event,
    Emitter<LoginState> emit,
  ) async {
    emit(state.copyWith(status: FormzSubmissionStatus.inProgress));
    try {
      await _authenticationRepository.logInWithGoogle();
      emit(state.copyWith(status: FormzSubmissionStatus.success));
    } on LogInWithGoogleFailure catch (e) {
      debugPrint(e.toString());
      emit(
        state.copyWith(
          status: FormzSubmissionStatus.failure,
        ),
      );
    } catch (_) {
      emit(state.copyWith(status: FormzSubmissionStatus.failure));
    }
  }
}
