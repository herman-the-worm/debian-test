part of 'login_bloc.dart';

enum LoginError { error, initial }

@freezed
class LoginState with _$LoginState {
  const factory LoginState({
    required FormzSubmissionStatus status,
    required UsernameDataFieldModel usernameDataFieldModel,
    required PasswordFieldModel passwordFieldModel,
    required LoginError error,
    required bool isValid,
  }) = _LoginState;
}
