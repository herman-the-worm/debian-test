// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'login_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$LoginEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LoginEventCopyWith<$Res> {
  factory $LoginEventCopyWith(
          LoginEvent value, $Res Function(LoginEvent) then) =
      _$LoginEventCopyWithImpl<$Res, LoginEvent>;
}

/// @nodoc
class _$LoginEventCopyWithImpl<$Res, $Val extends LoginEvent>
    implements $LoginEventCopyWith<$Res> {
  _$LoginEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;
}

/// @nodoc
abstract class _$$LoginFormUsernameChangedImplCopyWith<$Res> {
  factory _$$LoginFormUsernameChangedImplCopyWith(
          _$LoginFormUsernameChangedImpl value,
          $Res Function(_$LoginFormUsernameChangedImpl) then) =
      __$$LoginFormUsernameChangedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String username});
}

/// @nodoc
class __$$LoginFormUsernameChangedImplCopyWithImpl<$Res>
    extends _$LoginEventCopyWithImpl<$Res, _$LoginFormUsernameChangedImpl>
    implements _$$LoginFormUsernameChangedImplCopyWith<$Res> {
  __$$LoginFormUsernameChangedImplCopyWithImpl(
      _$LoginFormUsernameChangedImpl _value,
      $Res Function(_$LoginFormUsernameChangedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? username = null,
  }) {
    return _then(_$LoginFormUsernameChangedImpl(
      null == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoginFormUsernameChangedImpl
    with DiagnosticableTreeMixin
    implements _LoginFormUsernameChanged {
  const _$LoginFormUsernameChangedImpl(this.username);

  @override
  final String username;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginEvent.loginFormUsernameChanged(username: $username)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'LoginEvent.loginFormUsernameChanged'))
      ..add(DiagnosticsProperty('username', username));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoginFormUsernameChangedImpl &&
            (identical(other.username, username) ||
                other.username == username));
  }

  @override
  int get hashCode => Object.hash(runtimeType, username);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoginFormUsernameChangedImplCopyWith<_$LoginFormUsernameChangedImpl>
      get copyWith => __$$LoginFormUsernameChangedImplCopyWithImpl<
          _$LoginFormUsernameChangedImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) {
    return loginFormUsernameChanged(username);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) {
    return loginFormUsernameChanged?.call(username);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (loginFormUsernameChanged != null) {
      return loginFormUsernameChanged(username);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) {
    return loginFormUsernameChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) {
    return loginFormUsernameChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) {
    if (loginFormUsernameChanged != null) {
      return loginFormUsernameChanged(this);
    }
    return orElse();
  }
}

abstract class _LoginFormUsernameChanged implements LoginEvent {
  const factory _LoginFormUsernameChanged(final String username) =
      _$LoginFormUsernameChangedImpl;

  String get username;
  @JsonKey(ignore: true)
  _$$LoginFormUsernameChangedImplCopyWith<_$LoginFormUsernameChangedImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$LoginFormPasswordChangedImplCopyWith<$Res> {
  factory _$$LoginFormPasswordChangedImplCopyWith(
          _$LoginFormPasswordChangedImpl value,
          $Res Function(_$LoginFormPasswordChangedImpl) then) =
      __$$LoginFormPasswordChangedImplCopyWithImpl<$Res>;
  @useResult
  $Res call({String password});
}

/// @nodoc
class __$$LoginFormPasswordChangedImplCopyWithImpl<$Res>
    extends _$LoginEventCopyWithImpl<$Res, _$LoginFormPasswordChangedImpl>
    implements _$$LoginFormPasswordChangedImplCopyWith<$Res> {
  __$$LoginFormPasswordChangedImplCopyWithImpl(
      _$LoginFormPasswordChangedImpl _value,
      $Res Function(_$LoginFormPasswordChangedImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? password = null,
  }) {
    return _then(_$LoginFormPasswordChangedImpl(
      null == password
          ? _value.password
          : password // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$LoginFormPasswordChangedImpl
    with DiagnosticableTreeMixin
    implements _LoginFormPasswordChanged {
  const _$LoginFormPasswordChangedImpl(this.password);

  @override
  final String password;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginEvent.loginFormPasswordChanged(password: $password)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'LoginEvent.loginFormPasswordChanged'))
      ..add(DiagnosticsProperty('password', password));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoginFormPasswordChangedImpl &&
            (identical(other.password, password) ||
                other.password == password));
  }

  @override
  int get hashCode => Object.hash(runtimeType, password);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoginFormPasswordChangedImplCopyWith<_$LoginFormPasswordChangedImpl>
      get copyWith => __$$LoginFormPasswordChangedImplCopyWithImpl<
          _$LoginFormPasswordChangedImpl>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) {
    return loginFormPasswordChanged(password);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) {
    return loginFormPasswordChanged?.call(password);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (loginFormPasswordChanged != null) {
      return loginFormPasswordChanged(password);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) {
    return loginFormPasswordChanged(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) {
    return loginFormPasswordChanged?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) {
    if (loginFormPasswordChanged != null) {
      return loginFormPasswordChanged(this);
    }
    return orElse();
  }
}

abstract class _LoginFormPasswordChanged implements LoginEvent {
  const factory _LoginFormPasswordChanged(final String password) =
      _$LoginFormPasswordChangedImpl;

  String get password;
  @JsonKey(ignore: true)
  _$$LoginFormPasswordChangedImplCopyWith<_$LoginFormPasswordChangedImpl>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$LoginSubmittedImplCopyWith<$Res> {
  factory _$$LoginSubmittedImplCopyWith(_$LoginSubmittedImpl value,
          $Res Function(_$LoginSubmittedImpl) then) =
      __$$LoginSubmittedImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoginSubmittedImplCopyWithImpl<$Res>
    extends _$LoginEventCopyWithImpl<$Res, _$LoginSubmittedImpl>
    implements _$$LoginSubmittedImplCopyWith<$Res> {
  __$$LoginSubmittedImplCopyWithImpl(
      _$LoginSubmittedImpl _value, $Res Function(_$LoginSubmittedImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoginSubmittedImpl
    with DiagnosticableTreeMixin
    implements _LoginSubmitted {
  const _$LoginSubmittedImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginEvent.loginSubmitted()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'LoginEvent.loginSubmitted'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoginSubmittedImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) {
    return loginSubmitted();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) {
    return loginSubmitted?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (loginSubmitted != null) {
      return loginSubmitted();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) {
    return loginSubmitted(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) {
    return loginSubmitted?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) {
    if (loginSubmitted != null) {
      return loginSubmitted(this);
    }
    return orElse();
  }
}

abstract class _LoginSubmitted implements LoginEvent {
  const factory _LoginSubmitted() = _$LoginSubmittedImpl;
}

/// @nodoc
abstract class _$$LoginWithGoogleImplCopyWith<$Res> {
  factory _$$LoginWithGoogleImplCopyWith(_$LoginWithGoogleImpl value,
          $Res Function(_$LoginWithGoogleImpl) then) =
      __$$LoginWithGoogleImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoginWithGoogleImplCopyWithImpl<$Res>
    extends _$LoginEventCopyWithImpl<$Res, _$LoginWithGoogleImpl>
    implements _$$LoginWithGoogleImplCopyWith<$Res> {
  __$$LoginWithGoogleImplCopyWithImpl(
      _$LoginWithGoogleImpl _value, $Res Function(_$LoginWithGoogleImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoginWithGoogleImpl
    with DiagnosticableTreeMixin
    implements _LoginWithGoogle {
  const _$LoginWithGoogleImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginEvent.loginWithGoogle()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'LoginEvent.loginWithGoogle'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoginWithGoogleImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) {
    return loginWithGoogle();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) {
    return loginWithGoogle?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (loginWithGoogle != null) {
      return loginWithGoogle();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) {
    return loginWithGoogle(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) {
    return loginWithGoogle?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) {
    if (loginWithGoogle != null) {
      return loginWithGoogle(this);
    }
    return orElse();
  }
}

abstract class _LoginWithGoogle implements LoginEvent {
  const factory _LoginWithGoogle() = _$LoginWithGoogleImpl;
}

/// @nodoc
abstract class _$$LoginResetImplCopyWith<$Res> {
  factory _$$LoginResetImplCopyWith(
          _$LoginResetImpl value, $Res Function(_$LoginResetImpl) then) =
      __$$LoginResetImplCopyWithImpl<$Res>;
}

/// @nodoc
class __$$LoginResetImplCopyWithImpl<$Res>
    extends _$LoginEventCopyWithImpl<$Res, _$LoginResetImpl>
    implements _$$LoginResetImplCopyWith<$Res> {
  __$$LoginResetImplCopyWithImpl(
      _$LoginResetImpl _value, $Res Function(_$LoginResetImpl) _then)
      : super(_value, _then);
}

/// @nodoc

class _$LoginResetImpl with DiagnosticableTreeMixin implements _LoginReset {
  const _$LoginResetImpl();

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginEvent.reset()';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties.add(DiagnosticsProperty('type', 'LoginEvent.reset'));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType && other is _$LoginResetImpl);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(String username) loginFormUsernameChanged,
    required TResult Function(String password) loginFormPasswordChanged,
    required TResult Function() loginSubmitted,
    required TResult Function() loginWithGoogle,
    required TResult Function() reset,
  }) {
    return reset();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult? Function(String username)? loginFormUsernameChanged,
    TResult? Function(String password)? loginFormPasswordChanged,
    TResult? Function()? loginSubmitted,
    TResult? Function()? loginWithGoogle,
    TResult? Function()? reset,
  }) {
    return reset?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(String username)? loginFormUsernameChanged,
    TResult Function(String password)? loginFormPasswordChanged,
    TResult Function()? loginSubmitted,
    TResult Function()? loginWithGoogle,
    TResult Function()? reset,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(_LoginFormUsernameChanged value)
        loginFormUsernameChanged,
    required TResult Function(_LoginFormPasswordChanged value)
        loginFormPasswordChanged,
    required TResult Function(_LoginSubmitted value) loginSubmitted,
    required TResult Function(_LoginWithGoogle value) loginWithGoogle,
    required TResult Function(_LoginReset value) reset,
  }) {
    return reset(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult? Function(_LoginFormUsernameChanged value)?
        loginFormUsernameChanged,
    TResult? Function(_LoginFormPasswordChanged value)?
        loginFormPasswordChanged,
    TResult? Function(_LoginSubmitted value)? loginSubmitted,
    TResult? Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult? Function(_LoginReset value)? reset,
  }) {
    return reset?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(_LoginFormUsernameChanged value)? loginFormUsernameChanged,
    TResult Function(_LoginFormPasswordChanged value)? loginFormPasswordChanged,
    TResult Function(_LoginSubmitted value)? loginSubmitted,
    TResult Function(_LoginWithGoogle value)? loginWithGoogle,
    TResult Function(_LoginReset value)? reset,
    required TResult orElse(),
  }) {
    if (reset != null) {
      return reset(this);
    }
    return orElse();
  }
}

abstract class _LoginReset implements LoginEvent {
  const factory _LoginReset() = _$LoginResetImpl;
}

/// @nodoc
mixin _$LoginState {
  FormzSubmissionStatus get status => throw _privateConstructorUsedError;
  UsernameDataFieldModel get usernameDataFieldModel =>
      throw _privateConstructorUsedError;
  PasswordFieldModel get passwordFieldModel =>
      throw _privateConstructorUsedError;
  LoginError get error => throw _privateConstructorUsedError;
  bool get isValid => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $LoginStateCopyWith<LoginState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LoginStateCopyWith<$Res> {
  factory $LoginStateCopyWith(
          LoginState value, $Res Function(LoginState) then) =
      _$LoginStateCopyWithImpl<$Res, LoginState>;
  @useResult
  $Res call(
      {FormzSubmissionStatus status,
      UsernameDataFieldModel usernameDataFieldModel,
      PasswordFieldModel passwordFieldModel,
      LoginError error,
      bool isValid});
}

/// @nodoc
class _$LoginStateCopyWithImpl<$Res, $Val extends LoginState>
    implements $LoginStateCopyWith<$Res> {
  _$LoginStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? usernameDataFieldModel = null,
    Object? passwordFieldModel = null,
    Object? error = null,
    Object? isValid = null,
  }) {
    return _then(_value.copyWith(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      usernameDataFieldModel: null == usernameDataFieldModel
          ? _value.usernameDataFieldModel
          : usernameDataFieldModel // ignore: cast_nullable_to_non_nullable
              as UsernameDataFieldModel,
      passwordFieldModel: null == passwordFieldModel
          ? _value.passwordFieldModel
          : passwordFieldModel // ignore: cast_nullable_to_non_nullable
              as PasswordFieldModel,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as LoginError,
      isValid: null == isValid
          ? _value.isValid
          : isValid // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LoginStateImplCopyWith<$Res>
    implements $LoginStateCopyWith<$Res> {
  factory _$$LoginStateImplCopyWith(
          _$LoginStateImpl value, $Res Function(_$LoginStateImpl) then) =
      __$$LoginStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {FormzSubmissionStatus status,
      UsernameDataFieldModel usernameDataFieldModel,
      PasswordFieldModel passwordFieldModel,
      LoginError error,
      bool isValid});
}

/// @nodoc
class __$$LoginStateImplCopyWithImpl<$Res>
    extends _$LoginStateCopyWithImpl<$Res, _$LoginStateImpl>
    implements _$$LoginStateImplCopyWith<$Res> {
  __$$LoginStateImplCopyWithImpl(
      _$LoginStateImpl _value, $Res Function(_$LoginStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? status = null,
    Object? usernameDataFieldModel = null,
    Object? passwordFieldModel = null,
    Object? error = null,
    Object? isValid = null,
  }) {
    return _then(_$LoginStateImpl(
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as FormzSubmissionStatus,
      usernameDataFieldModel: null == usernameDataFieldModel
          ? _value.usernameDataFieldModel
          : usernameDataFieldModel // ignore: cast_nullable_to_non_nullable
              as UsernameDataFieldModel,
      passwordFieldModel: null == passwordFieldModel
          ? _value.passwordFieldModel
          : passwordFieldModel // ignore: cast_nullable_to_non_nullable
              as PasswordFieldModel,
      error: null == error
          ? _value.error
          : error // ignore: cast_nullable_to_non_nullable
              as LoginError,
      isValid: null == isValid
          ? _value.isValid
          : isValid // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc

class _$LoginStateImpl with DiagnosticableTreeMixin implements _LoginState {
  const _$LoginStateImpl(
      {required this.status,
      required this.usernameDataFieldModel,
      required this.passwordFieldModel,
      required this.error,
      required this.isValid});

  @override
  final FormzSubmissionStatus status;
  @override
  final UsernameDataFieldModel usernameDataFieldModel;
  @override
  final PasswordFieldModel passwordFieldModel;
  @override
  final LoginError error;
  @override
  final bool isValid;

  @override
  String toString({DiagnosticLevel minLevel = DiagnosticLevel.info}) {
    return 'LoginState(status: $status, usernameDataFieldModel: $usernameDataFieldModel, passwordFieldModel: $passwordFieldModel, error: $error, isValid: $isValid)';
  }

  @override
  void debugFillProperties(DiagnosticPropertiesBuilder properties) {
    super.debugFillProperties(properties);
    properties
      ..add(DiagnosticsProperty('type', 'LoginState'))
      ..add(DiagnosticsProperty('status', status))
      ..add(
          DiagnosticsProperty('usernameDataFieldModel', usernameDataFieldModel))
      ..add(DiagnosticsProperty('passwordFieldModel', passwordFieldModel))
      ..add(DiagnosticsProperty('error', error))
      ..add(DiagnosticsProperty('isValid', isValid));
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LoginStateImpl &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.usernameDataFieldModel, usernameDataFieldModel) ||
                other.usernameDataFieldModel == usernameDataFieldModel) &&
            (identical(other.passwordFieldModel, passwordFieldModel) ||
                other.passwordFieldModel == passwordFieldModel) &&
            (identical(other.error, error) || other.error == error) &&
            (identical(other.isValid, isValid) || other.isValid == isValid));
  }

  @override
  int get hashCode => Object.hash(runtimeType, status, usernameDataFieldModel,
      passwordFieldModel, error, isValid);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$LoginStateImplCopyWith<_$LoginStateImpl> get copyWith =>
      __$$LoginStateImplCopyWithImpl<_$LoginStateImpl>(this, _$identity);
}

abstract class _LoginState implements LoginState {
  const factory _LoginState(
      {required final FormzSubmissionStatus status,
      required final UsernameDataFieldModel usernameDataFieldModel,
      required final PasswordFieldModel passwordFieldModel,
      required final LoginError error,
      required final bool isValid}) = _$LoginStateImpl;

  @override
  FormzSubmissionStatus get status;
  @override
  UsernameDataFieldModel get usernameDataFieldModel;
  @override
  PasswordFieldModel get passwordFieldModel;
  @override
  LoginError get error;
  @override
  bool get isValid;
  @override
  @JsonKey(ignore: true)
  _$$LoginStateImplCopyWith<_$LoginStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
