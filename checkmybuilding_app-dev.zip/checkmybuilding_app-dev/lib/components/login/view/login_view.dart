import 'package:checkmybuilding/components/login/login.dart';
import 'package:checkmybuilding/shared/constants/colors_theme_constant.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LoginBlocProviderWidget(
      childWidget: Scaffold(
        appBar: AppBar(
          backgroundColor: KCustomColorTheme.kDarkGrey,
        ),
        body: const LoginBodyWidget(),
      ),
    );
  }
}
